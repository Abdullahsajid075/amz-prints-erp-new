<?php
/**
 * Shared ERP API helpers — products catalog + CRM leads.
 *
 * @package AMZ_Prints
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'AMZ_PRINTS_ERP_API_DEFAULT' ) ) {
	define(
		'AMZ_PRINTS_ERP_API_DEFAULT',
		'https://amz-prints-api.vercel.app'
	);
}

if ( ! function_exists( 'amz_prints_erp_api_url' ) ) {
	/**
	 * ERP API base URL (Customizer override supported).
	 */
	function amz_prints_erp_api_url() {
		$url = trim( (string) amz_prints_mod( 'amz_erp_api_url', AMZ_PRINTS_ERP_API_DEFAULT ) );
		return $url ? $url : AMZ_PRINTS_ERP_API_DEFAULT;
	}
}

/**
 * Decode ERP JSON payload (list or object).
 *
 * @param string $raw Response body.
 * @param int    $code HTTP status.
 * @return array|WP_Error
 */
function amz_prints_erp_decode_response( $raw, $code = 200 ) {
	$data = json_decode( (string) $raw, true );
	if ( ! is_array( $data ) ) {
		$preview = trim( wp_strip_all_tags( (string) $raw ) );
		$preview = $preview ? substr( $preview, 0, 120 ) : '';
		return new WP_Error(
			'amz_erp_bad_response',
			$preview
				? sprintf( __( 'Unexpected ERP response: %s', 'amz-prints' ), $preview )
				: __( 'Unexpected response from ERP API.', 'amz-prints' )
		);
	}

	// Object error payloads include _status; bare product lists do not.
	$app_status = ( isset( $data['_status'] ) && ! isset( $data[0] ) ) ? (int) $data['_status'] : (int) $code;
	if ( $app_status >= 400 ) {
		$msg = ! empty( $data['message'] )
			? sanitize_text_field( $data['message'] )
			: __( 'ERP request failed.', 'amz-prints' );
		return new WP_Error( 'amz_erp_http_' . $app_status, $msg, array( 'status' => $app_status ) );
	}

	return $data;
}

/**
 * Low-level ERP request (Supabase API, same ?path= contract as the ERP app).
 *
 * The live API is https://amz-prints-api.vercel.app (Supabase). Older Apps Script
 * URLs answer with a 302; those are still followed so a saved legacy URL keeps working.
 *
 * @param string     $method GET|POST|PUT|PATCH|DELETE
 * @param string     $path   API path starting with /
 * @param array|null $body   JSON body for non-GET
 * @return array|WP_Error
 */
function amz_prints_erp_request( $method, $path, $body = null, $token = '', $timeout = 30 ) {
	$method = strtoupper( (string) $method );
	$path   = '/' . ltrim( (string) $path, '/' );
	$api    = amz_prints_erp_api_url();
	$url    = add_query_arg( 'path', $path, $api );
	$token  = trim( (string) $token );
	if ( '' !== $token ) {
		$url = add_query_arg( 'token', $token, $url );
	}

	$http_method = $method;
	if ( ! in_array( $http_method, array( 'GET', 'POST' ), true ) ) {
		$url         = add_query_arg( '_method', $http_method, $url );
		$http_method = 'POST';
	}

	$args = array(
		'timeout'     => (int) $timeout,
		'redirection' => 0, // handle GAS 302 ourselves
		'headers'     => array(
			'Accept'       => 'application/json',
			'Content-Type' => 'text/plain;charset=utf-8',
		),
	);

	if ( null !== $body && 'POST' === $http_method ) {
		$args['body'] = wp_json_encode( $body );
	}

	$response = ( 'GET' === $http_method )
		? wp_remote_get( $url, $args )
		: wp_remote_post( $url, $args );

	if ( is_wp_error( $response ) ) {
		return $response;
	}

	$code = (int) wp_remote_retrieve_response_code( $response );
	$raw  = wp_remote_retrieve_body( $response );

	// GAS web app: POST/GET often 302 to script.googleusercontent.com/macros/echo?...
	if ( in_array( $code, array( 301, 302, 303, 307, 308 ), true ) ) {
		$location = wp_remote_retrieve_header( $response, 'location' );
		if ( ! $location ) {
			return new WP_Error( 'amz_erp_redirect', __( 'ERP API redirected without a Location header.', 'amz-prints' ) );
		}
		$follow = wp_remote_get(
			$location,
			array(
				'timeout'     => 30,
				'redirection' => 3,
				'headers'     => array( 'Accept' => 'application/json' ),
			)
		);
		if ( is_wp_error( $follow ) ) {
			return $follow;
		}
		$code = (int) wp_remote_retrieve_response_code( $follow );
		$raw  = wp_remote_retrieve_body( $follow );
	}

	return amz_prints_erp_decode_response( $raw, $code );
}

/**
 * Live active products from ERP (cached ~5 minutes).
 *
 * @param bool $force_refresh Bypass transient.
 * @return array List of product arrays (empty on failure).
 */
function amz_prints_erp_flag( $value ) {
	if ( is_bool( $value ) ) {
		return $value;
	}
	$raw = strtolower( trim( (string) $value ) );
	if ( in_array( $raw, array( '1', 'true', 'yes', 'on' ), true ) ) {
		return true;
	}
	if ( in_array( $raw, array( '0', 'false', 'no', 'off' ), true ) ) {
		return false;
	}
	return null;
}

/**
 * Turn an ERP data:image into a resized file in uploads so pages link to it
 * instead of inlining megabytes of base64. Falls back to the original value.
 *
 * @param string $src Image src from ERP.
 * @return string
 */
function amz_prints_erp_localize_image( $src ) {
	$src = trim( (string) $src );
	if ( ! preg_match( '#^data:image/(jpeg|jpg|png|webp|gif);base64,#i', $src, $m ) ) {
		return $src;
	}
	$uploads = wp_upload_dir();
	if ( ! empty( $uploads['error'] ) ) {
		return $src;
	}
	$ext  = strtolower( 'jpeg' === strtolower( $m[1] ) ? 'jpg' : $m[1] );
	$dir  = trailingslashit( $uploads['basedir'] ) . 'amz-products';
	$name = md5( $src ) . '.' . $ext;
	$path = $dir . '/' . $name;
	$url  = trailingslashit( $uploads['baseurl'] ) . 'amz-products/' . $name;

	if ( file_exists( $path ) ) {
		return $url;
	}
	if ( strlen( $src ) > 15 * MB_IN_BYTES || ! wp_mkdir_p( $dir ) ) {
		return $src;
	}
	$bin = base64_decode( substr( $src, strpos( $src, ',' ) + 1 ), true );
	if ( false === $bin || '' === $bin ) {
		return $src;
	}
	if ( false === file_put_contents( $path, $bin ) ) {
		return $src;
	}
	if ( 'gif' !== $ext && function_exists( 'wp_get_image_editor' ) ) {
		$editor = wp_get_image_editor( $path );
		if ( ! is_wp_error( $editor ) ) {
			$size = $editor->get_size();
			if ( ! empty( $size['width'] ) && ( $size['width'] > 900 || $size['height'] > 900 ) ) {
				$editor->resize( 900, 900, false );
			}
			$editor->set_quality( 80 );
			$editor->save( $path );
			$editor->resize( 420, 420, false );
			$editor->set_quality( 78 );
			$editor->save( substr( $path, 0, -strlen( $ext ) - 1 ) . '-sm.' . $ext );
		}
	}
	return $url;
}

/**
 * Small (420px) version of a localized ERP image for cards and the product rail.
 *
 * @param string $src Product image src.
 * @return string Escaped src.
 */
function amz_prints_product_thumb_src( $src ) {
	$src     = trim( (string) $src );
	$uploads = wp_upload_dir();
	$base    = trailingslashit( $uploads['baseurl'] ) . 'amz-products/';
	if ( $src && 0 === strpos( $src, $base ) ) {
		$file = substr( $src, strlen( $base ) );
		$dot  = strrpos( $file, '.' );
		if ( false !== $dot ) {
			$small = substr( $file, 0, $dot ) . '-sm' . substr( $file, $dot );
			if ( file_exists( trailingslashit( $uploads['basedir'] ) . 'amz-products/' . $small ) ) {
				return esc_url( $base . $small );
			}
		}
	}
	return function_exists( 'amz_prints_product_img_src' ) ? amz_prints_product_img_src( $src ) : esc_url( $src );
}

function amz_prints_erp_get_products( $force_refresh = false ) {
	$cache_key = 'amz_prints_erp_products_v5';
	$stale_key = 'amz_prints_erp_products_last';
	if ( ! $force_refresh ) {
		$cached = get_transient( $cache_key );
		if ( is_array( $cached ) ) {
			return $cached;
		}
	}

	$data = amz_prints_erp_request( 'GET', '/public/products', null, '', 12 );
	if ( is_wp_error( $data ) || ! is_array( $data ) ) {
		$stale = get_option( $stale_key, array() );
		$stale = is_array( $stale ) ? $stale : array();
		// Short retry window so a slow or down ERP doesn't stall every page view.
		set_transient( $cache_key, $stale, 2 * MINUTE_IN_SECONDS );
		return $stale;
	}

	// Payload may be a bare list or { products: [...] }
	$list = array();
	if ( isset( $data['products'] ) && is_array( $data['products'] ) ) {
		$list = $data['products'];
	} elseif ( array_keys( $data ) === range( 0, count( $data ) - 1 ) ) {
		$list = $data;
	} elseif ( is_array( $data ) ) {
		// Associative single? ignore. Prefer numeric list only.
		$looks_list = true;
		foreach ( $data as $item ) {
			if ( ! is_array( $item ) ) {
				$looks_list = false;
				break;
			}
		}
		if ( $looks_list ) {
			$list = array_values( $data );
		}
	}

	$products = array();
	foreach ( $list as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$name = trim( (string) ( $row['name'] ?? '' ) );
		if ( ! $name ) {
			continue;
		}
		$price = isset( $row['basePrice'] ) ? (float) $row['basePrice'] : ( isset( $row['rate'] ) ? (float) $row['rate'] : 0 );
		$images = array();
		if ( ! empty( $row['images'] ) && is_array( $row['images'] ) ) {
			foreach ( $row['images'] as $img ) {
				$img = amz_prints_erp_localize_image( $img );
				if ( $img && ! in_array( $img, $images, true ) ) {
					$images[] = $img;
				}
			}
		}
		$primary = amz_prints_erp_localize_image( (string) ( $row['image'] ?? $row['photo'] ?? '' ) );
		if ( $primary && ! in_array( $primary, $images, true ) ) {
			array_unshift( $images, $primary );
		} elseif ( ! $primary && ! empty( $images ) ) {
			$primary = $images[0];
		}

		$active = amz_prints_erp_flag( $row['active'] ?? null );
		$status = strtolower( trim( (string) ( $row['status'] ?? 'active' ) ) );
		if ( false === $active || 'inactive' === $status ) {
			continue;
		}
		$on_site = amz_prints_erp_flag( $row['showOnWebsite'] ?? null );
		if ( false === $on_site ) {
			continue;
		}
		$sale = isset( $row['effectivePrice'] ) ? (float) $row['effectivePrice'] : ( isset( $row['salePrice'] ) ? (float) $row['salePrice'] : 0 );
		if ( $sale > 0 ) {
			$price = $sale;
		}
		$variations = array();
		if ( ! empty( $row['variations'] ) && is_array( $row['variations'] ) ) {
			foreach ( $row['variations'] as $var ) {
				if ( ! is_array( $var ) || empty( $var['name'] ) ) {
					continue;
				}
				$variations[] = array(
					'id'    => (string) ( $var['id'] ?? '' ),
					'name'  => (string) $var['name'],
					'price' => isset( $var['price'] ) ? (float) $var['price'] : 0,
				);
			}
		}

		$products[] = array(
			'id'           => (string) ( $row['id'] ?? '' ),
			'name'         => $name,
			'category'     => (string) ( $row['category'] ?? '' ),
			'productType'  => (string) ( $row['productType'] ?? 'Product' ),
			'basePrice'    => $price,
			'unit'         => (string) ( $row['unit'] ?? 'per piece' ),
			'description'  => (string) ( $row['fullDescription'] ?? $row['description'] ?? '' ),
			'material'     => (string) ( $row['material'] ?? '' ),
			'size'         => (string) ( $row['size'] ?? '' ),
			'minQuantity'  => isset( $row['minQuantity'] ) ? (float) $row['minQuantity'] : 1,
			'image'        => $primary,
			'images'       => $images,
			'showOnTop'    => true === amz_prints_erp_flag( $row['showOnTop'] ?? null ),
			'variations'   => $variations,
		);
	}

	usort(
		$products,
		static function ( $a, $b ) {
			if ( ! empty( $a['showOnTop'] ) !== ! empty( $b['showOnTop'] ) ) {
				return ! empty( $a['showOnTop'] ) ? -1 : 1;
			}
			return strcmp( (string) $b['id'], (string) $a['id'] );
		}
	);

	set_transient( $cache_key, $products, 5 * MINUTE_IN_SECONDS );
	update_option( $stale_key, $products, false );
	return $products;
}

/**
 * Shop and home catalog must not sit in a full-page cache.
 */
function amz_prints_catalog_nocache() {
	if ( is_admin() ) {
		return;
	}
	$catalog = is_front_page() || is_page( array( 'products', 'product' ) );
	if ( ! $catalog ) {
		return;
	}
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	nocache_headers();
}
add_action( 'template_redirect', 'amz_prints_catalog_nocache', 0 );

/**
 * Format ERP price for display.
 *
 * @param array $product Product row.
 * @return string
 */
function amz_prints_erp_product_price_label( $product ) {
	$price = isset( $product['basePrice'] ) ? (float) $product['basePrice'] : 0;
	$unit  = ! empty( $product['unit'] ) ? $product['unit'] : '';
	if ( $price <= 0 ) {
		return __( 'Get a quote', 'amz-prints' );
	}
	$formatted = 'From Rs. ' . number_format_i18n( $price, $price == floor( $price ) ? 0 : 2 );
	return $unit ? ( $formatted . ' / ' . $unit ) : $formatted;
}

/**
 * Create / update CRM lead via ERP public API.
 *
 * @param array $payload Lead fields.
 * @return array|WP_Error
 */
function amz_prints_erp_create_lead( $payload ) {
	$payload = is_array( $payload ) ? $payload : array();
	$name    = trim( (string) ( $payload['name'] ?? '' ) );
	$phone   = trim( (string) ( $payload['phone'] ?? '' ) );
	$email   = trim( (string) ( $payload['email'] ?? '' ) );

	if ( ! $name ) {
		return new WP_Error( 'amz_lead_name', __( 'Name is required.', 'amz-prints' ) );
	}
	if ( ! $phone && ! $email ) {
		return new WP_Error( 'amz_lead_contact', __( 'Phone or email is required.', 'amz-prints' ) );
	}

	$body = array(
		'name'      => $name,
		'phone'     => $phone,
		'email'     => $email,
		'company'   => trim( (string) ( $payload['company'] ?? '' ) ),
		'product'   => trim( (string) ( $payload['product'] ?? $payload['service'] ?? '' ) ),
		'quantity'  => trim( (string) ( $payload['quantity'] ?? '' ) ),
		'neededBy'  => trim( (string) ( $payload['neededBy'] ?? $payload['needed_by'] ?? '' ) ),
		'details'   => trim( (string) ( $payload['details'] ?? $payload['message'] ?? '' ) ),
		'source'    => trim( (string) ( $payload['source'] ?? 'website' ) ),
	);

	return amz_prints_erp_request( 'POST', '/public/lead', $body );
}

/**
 * AJAX: submit website lead to ERP CRM (then JS opens WhatsApp).
 */
function amz_prints_ajax_submit_lead() {
	check_ajax_referer( 'amz_prints_lead', 'nonce' );

	$payload = array(
		'name'      => isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '',
		'phone'     => isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '',
		'email'     => isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '',
		'company'   => isset( $_POST['company'] ) ? sanitize_text_field( wp_unslash( $_POST['company'] ) ) : '',
		'product'   => isset( $_POST['product'] ) ? sanitize_text_field( wp_unslash( $_POST['product'] ) ) : '',
		'quantity'  => isset( $_POST['quantity'] ) ? sanitize_text_field( wp_unslash( $_POST['quantity'] ) ) : '',
		'neededBy'  => isset( $_POST['needed_by'] ) ? sanitize_text_field( wp_unslash( $_POST['needed_by'] ) ) : '',
		'details'   => isset( $_POST['details'] ) ? sanitize_textarea_field( wp_unslash( $_POST['details'] ) ) : '',
		'source'    => isset( $_POST['source'] ) ? sanitize_text_field( wp_unslash( $_POST['source'] ) ) : 'website-quote',
	);

	if ( empty( $payload['details'] ) && ! empty( $_POST['message'] ) ) {
		$payload['details'] = sanitize_textarea_field( wp_unslash( $_POST['message'] ) );
	}

	$result = amz_prints_erp_create_lead( $payload );
	if ( is_wp_error( $result ) ) {
		wp_send_json_error(
			array( 'message' => $result->get_error_message() ),
			400
		);
	}

	wp_send_json_success(
		array(
			'ok'         => ! empty( $result['ok'] ),
			'customerId' => isset( $result['customerId'] ) ? $result['customerId'] : '',
			'stage'      => isset( $result['stage'] ) ? $result['stage'] : 'lead',
		)
	);
}
add_action( 'wp_ajax_amz_prints_submit_lead', 'amz_prints_ajax_submit_lead' );
add_action( 'wp_ajax_nopriv_amz_prints_submit_lead', 'amz_prints_ajax_submit_lead' );
