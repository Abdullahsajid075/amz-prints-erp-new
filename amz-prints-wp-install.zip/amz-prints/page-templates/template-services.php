<?php
/**
 * Template Name: Services
 *
 * @package AMZ_Prints
 */

get_header();
$catalog = amz_prints_services_catalog();
?>

<?php
if ( function_exists( 'amz_prints_page_banner' ) ) {
	amz_prints_page_banner( 'services' );
}
?>

<section class="section" style="padding-bottom:0">
	<div class="container land-quick__grid">
		<a class="land-quick__card land-quick__card--orange reveal" data-reveal href="#printing-services">
			<span><?php esc_html_e( 'Press', 'amz-prints' ); ?></span>
			<strong><?php esc_html_e( 'Print & branding', 'amz-prints' ); ?></strong>
		</a>
		<a class="land-quick__card land-quick__card--blue reveal" data-reveal href="<?php echo esc_url( home_url( '/digital-services/' ) ); ?>">
			<span><?php esc_html_e( 'Screens', 'amz-prints' ); ?></span>
			<strong><?php esc_html_e( 'IT & digital', 'amz-prints' ); ?></strong>
		</a>
		<a class="land-quick__card land-quick__card--green reveal" data-reveal href="<?php echo esc_url( home_url( '/nadra-e-services/' ) ); ?>">
			<span><?php esc_html_e( 'Public', 'amz-prints' ); ?></span>
			<strong><?php esc_html_e( 'NADRA e-services', 'amz-prints' ); ?></strong>
		</a>
		<a class="land-quick__card land-quick__card--mix reveal" data-reveal href="<?php echo esc_url( home_url( '/products/' ) ); ?>">
			<span><?php esc_html_e( 'Shop', 'amz-prints' ); ?></span>
			<strong><?php esc_html_e( 'Buy online', 'amz-prints' ); ?></strong>
		</a>
	</div>
</section>

<section class="section section--services-catalog">
	<div class="container">
		<nav class="services-jump reveal" data-reveal>
			<?php foreach ( $catalog as $cat ) : ?>
				<a href="#<?php echo esc_attr( $cat['slug'] ); ?>"><?php echo esc_html( amz_prints_svc_label( $cat ) ); ?></a>
			<?php endforeach; ?>
		</nav>

		<?php foreach ( $catalog as $cat ) : ?>
			<section class="service-category reveal" data-reveal id="<?php echo esc_attr( $cat['slug'] ); ?>">
				<a class="service-category__banner" href="<?php echo esc_url( 'web-digital-services' === $cat['slug'] ? home_url( '/digital-services/' ) : amz_prints_service_section_url( $cat['slug'] ) ); ?>">
					<img src="<?php echo esc_url( $cat['image'] ); ?>" alt="<?php echo esc_attr( amz_prints_svc_label( $cat ) ); ?>" loading="lazy">
					<div class="service-category__banner-copy">
						<h2><?php echo esc_html( amz_prints_svc_label( $cat ) ); ?></h2>
						<span><?php echo esc_html( count( $cat['items'] ) ); ?> <?php echo esc_html( amz_prints_is_rtl() ? 'سروسز' : 'services' ); ?></span>
					</div>
				</a>
				<?php if ( 'web-digital-services' === $cat['slug'] ) : ?>
					<p class="service-category__note">
						<a class="text-link" href="<?php echo esc_url( home_url( '/digital-services/' ) ); ?>"><?php esc_html_e( 'Open full Digital Services details', 'amz-prints' ); ?></a>
					</p>
				<?php endif; ?>
				<div class="service-category__grid">
					<?php foreach ( $cat['items'] as $item ) : ?>
						<a class="service-chip" href="<?php echo esc_url( amz_prints_service_quote_url( $item['en'] ) ); ?>">
							<h3><?php echo esc_html( amz_prints_svc_label( $item ) ); ?></h3>
							<span><?php echo esc_html( amz_t( 'request_quote' ) ); ?> →</span>
						</a>
					<?php endforeach; ?>
				</div>
			</section>
		<?php endforeach; ?>
	</div>
</section>

<?php if ( function_exists( 'amz_prints_catalog_promo' ) ) { amz_prints_catalog_promo( 'services' ); } ?>

<section class="section section--cta">
	<div class="container cta-band reveal" data-reveal>
		<div class="cta-band__copy">
			<h2><?php echo esc_html( amz_t( 'mega_cta' ) ); ?></h2>
			<p><?php echo esc_html( amz_t( 'mega_cta_sub' ) ); ?></p>
		</div>
		<a class="btn btn--primary btn--lg" href="<?php echo esc_url( home_url( '/quote/' ) ); ?>"><?php echo esc_html( amz_t( 'quote' ) ); ?></a>
	</div>
</section>

<?php get_footer(); ?>
