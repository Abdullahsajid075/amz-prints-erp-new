<?php
/**
 * Customer portal — email login, Google verify reset, read-only account.
 *
 * @package AMZ_Prints
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const AMZ_PRINTS_CUSTOMER_COOKIE = 'amz_cust';

/**
 * Start session early for portal flash messages.
 */
function amz_prints_customer_boot() {
	if ( ! session_id() && ! headers_sent() ) {
		session_start( array(
			'cookie_httponly' => true,
			'cookie_samesite' => 'Lax',
		) );
	}
}
add_action( 'init', 'amz_prints_customer_boot', 1 );

function amz_prints_customer_token() {
	if ( ! empty( $_COOKIE[ AMZ_PRINTS_CUSTOMER_COOKIE ] ) ) {
		return sanitize_text_field( wp_unslash( $_COOKIE[ AMZ_PRINTS_CUSTOMER_COOKIE ] ) );
	}
	return '';
}

function amz_prints_customer_is_logged_in() {
	return (bool) amz_prints_customer_token();
}

function amz_prints_customer_current_email() {
	$token = amz_prints_customer_token();
	if ( ! $token ) {
		return '';
	}
	$local = amz_prints_local_session_customer( $token );
	return strtolower( trim( (string) ( $local['customer']['email'] ?? '' ) ) );
}

function amz_prints_customer_cookie_paths() {
	$paths = array( '/', (string) COOKIEPATH, (string) SITECOOKIEPATH );
	return array_values( array_unique( array_filter( $paths ) ) );
}

function amz_prints_customer_expire_cookie( $name ) {
	foreach ( amz_prints_customer_cookie_paths() as $path ) {
		setcookie( $name, '', array(
			'expires'  => time() - HOUR_IN_SECONDS,
			'path'     => $path,
			'secure'   => is_ssl(),
			'httponly' => true,
			'samesite' => 'Lax',
		) );
	}
	unset( $_COOKIE[ $name ] );
}

function amz_prints_customer_set_token( $token ) {
	$token = (string) $token;
	amz_prints_customer_expire_cookie( 'amz_customer_token' );
	$expire = time() + WEEK_IN_SECONDS;
	setcookie( AMZ_PRINTS_CUSTOMER_COOKIE, $token, array(
		'expires'  => $expire,
		'path'     => '/',
		'secure'   => is_ssl(),
		'httponly' => true,
		'samesite' => 'Lax',
	) );
	$_COOKIE[ AMZ_PRINTS_CUSTOMER_COOKIE ] = $token;
}

function amz_prints_customer_clear_token() {
	amz_prints_customer_expire_cookie( AMZ_PRINTS_CUSTOMER_COOKIE );
	amz_prints_customer_expire_cookie( 'amz_customer_token' );
}

function amz_prints_customer_login_url( $redirect = '' ) {
	$url = home_url( '/customer-login/' );
	if ( $redirect ) {
		$url = add_query_arg( 'redirect', $redirect, $url );
	}
	return $url;
}

function amz_prints_customer_account_url() {
	return home_url( '/my-account/' );
}

function amz_prints_customer_signup_url( $redirect = '' ) {
	$url = home_url( '/customer-signup/' );
	if ( $redirect ) {
		$url = add_query_arg( 'redirect', $redirect, $url );
	}
	return $url;
}

function amz_prints_customer_profile_url() {
	return home_url( '/my-account/#profile' );
}

function amz_prints_customer_normalize_phone( $phone ) {
	$phone = preg_replace( '/[\s\-().]/', '', trim( (string) $phone ) );
	if ( 0 === strpos( $phone, '00' ) ) {
		$phone = '+' . substr( $phone, 2 );
	}
	return $phone;
}

function amz_prints_customer_phone_error( $phone ) {
	$phone = amz_prints_customer_normalize_phone( $phone );
	if ( ! preg_match( '/^\+[1-9]\d{7,14}$/', $phone ) ) {
		return __( 'Enter a mobile number with country code, for example +923001234567.', 'amz-prints' );
	}
	return '';
}

function amz_prints_customer_address_error( $address ) {
	$address = trim( preg_replace( '/\s+/', ' ', (string) $address ) );
	if ( strlen( $address ) < 8 ) {
		return __( 'Enter a complete delivery address (street, area, and city).', 'amz-prints' );
	}
	return '';
}

/**
 * Name, email, country-code phone, and delivery address.
 *
 * @return array|WP_Error
 */
function amz_prints_customer_validate_identity( $name, $email, $phone, $address, $require_address = true ) {
	$name    = trim( (string) $name );
	$email   = strtolower( sanitize_email( (string) $email ) );
	$phone   = amz_prints_customer_normalize_phone( $phone );
	$address = trim( (string) $address );
	if ( strlen( $name ) < 2 ) {
		return new WP_Error( 'amz_name', __( 'Enter your full name.', 'amz-prints' ) );
	}
	if ( ! is_email( $email ) || ! preg_match( '/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $email ) ) {
		return new WP_Error( 'amz_email', __( 'Enter a correct email address.', 'amz-prints' ) );
	}
	$phone_error = amz_prints_customer_phone_error( $phone );
	if ( $phone_error ) {
		return new WP_Error( 'amz_phone', $phone_error );
	}
	if ( $require_address ) {
		$address_error = amz_prints_customer_address_error( $address );
		if ( $address_error ) {
			return new WP_Error( 'amz_address', $address_error );
		}
	}
	return array(
		'name'    => $name,
		'email'   => $email,
		'phone'   => $phone,
		'address' => $address,
	);
}

function amz_prints_customer_profile_is_complete( $customer = null ) {
	if ( ! is_array( $customer ) ) {
		$token = amz_prints_customer_token();
		$local = $token ? amz_prints_local_session_customer( $token ) : null;
		$customer = ( is_array( $local ) && ! empty( $local['customer'] ) ) ? $local['customer'] : array();
	}
	$checked = amz_prints_customer_validate_identity(
		$customer['name'] ?? '',
		$customer['email'] ?? '',
		$customer['phone'] ?? '',
		$customer['address'] ?? '',
		true
	);
	return ! is_wp_error( $checked );
}

/**
 * Shared secret so WordPress can prove it already verified Google
 * (Apps Script then does not need UrlFetchApp / external_request).
 */
function amz_prints_customer_portal_key() {
	$key = trim( (string) amz_prints_mod( 'amz_customer_portal_key', '' ) );
	if ( strlen( $key ) >= 24 ) {
		return $key;
	}
	try {
		$key = bin2hex( random_bytes( 24 ) );
	} catch ( Exception $e ) {
		$key = wp_generate_password( 48, false, false );
	}
	set_theme_mod( 'amz_customer_portal_key', $key );
	return $key;
}

/**
 * Verify Google ID token on WordPress (avoids Apps Script UrlFetchApp permission error).
 *
 * @param string $id_token Google credential / ID token
 * @return array|WP_Error { email, name, aud }
 */
function amz_prints_verify_google_id_token( $id_token ) {
	$token = trim( (string) $id_token );
	if ( ! $token ) {
		return new WP_Error( 'amz_google_token', __( 'Google ID token required.', 'amz-prints' ) );
	}

	$url  = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . rawurlencode( $token );
	$res  = wp_remote_get( $url, array( 'timeout' => 15 ) );
	if ( is_wp_error( $res ) ) {
		return new WP_Error( 'amz_google_http', __( 'Could not reach Google to verify sign-in. Try again.', 'amz-prints' ) );
	}
	$code = (int) wp_remote_retrieve_response_code( $res );
	$body = json_decode( (string) wp_remote_retrieve_body( $res ), true );
	if ( 200 !== $code || ! is_array( $body ) ) {
		return new WP_Error( 'amz_google_verify', __( 'Google verification failed. Sign in again.', 'amz-prints' ) );
	}

	$email    = strtolower( trim( (string) ( $body['email'] ?? '' ) ) );
	$verified = ! empty( $body['email_verified'] ) && ( true === $body['email_verified'] || 'true' === (string) $body['email_verified'] );
	if ( ! $email || ! $verified ) {
		return new WP_Error( 'amz_google_email', __( 'Google email is not verified.', 'amz-prints' ) );
	}

	$expected_aud = trim( (string) amz_prints_mod( 'amz_google_client_id', '' ) );
	$aud          = (string) ( $body['aud'] ?? '' );
	if ( $expected_aud && $aud && $aud !== $expected_aud ) {
		return new WP_Error( 'amz_google_aud', __( 'Google sign-in could not be verified. Try again.', 'amz-prints' ) );
	}

	return array(
		'email' => $email,
		'name'  => (string) ( $body['name'] ?? '' ),
		'aud'   => $aud,
	);
}

/**
 * Call ERP customer portal endpoints.
 *
 * @param string $path API path
 * @param array  $body JSON body
 * @return array|WP_Error
 */
function amz_prints_customer_api( $path, $body = array() ) {
	if ( ! function_exists( 'amz_prints_erp_request' ) ) {
		return new WP_Error( 'amz_erp_missing', __( 'ERP API helper missing.', 'amz-prints' ) );
	}
	return amz_prints_erp_request( 'POST', $path, $body );
}

function amz_prints_local_customers() {
	$all = get_option( 'amz_prints_local_customers', array() );
	return is_array( $all ) ? $all : array();
}

function amz_prints_local_customer_save( $email, $row ) {
	$all = amz_prints_local_customers();
	$all[ strtolower( $email ) ] = $row;
	update_option( 'amz_prints_local_customers', $all, false );
}

function amz_prints_local_customer_get( $email ) {
	$all = amz_prints_local_customers();
	$key = strtolower( trim( (string) $email ) );
	return isset( $all[ $key ] ) && is_array( $all[ $key ] ) ? $all[ $key ] : null;
}

function amz_prints_customer_redirect_from_post() {
	$redirect = isset( $_POST['redirect'] ) ? esc_url_raw( wp_unslash( $_POST['redirect'] ) ) : '';
	return $redirect ? wp_validate_redirect( $redirect, amz_prints_customer_account_url() ) : amz_prints_customer_account_url();
}

/**
 * Website session that does not depend on the ERP Google or session routes.
 */
function amz_prints_customer_sign_in_local( $email, $profile, $password = '', $erp_token = '' ) {
	$email   = strtolower( trim( (string) $email ) );
	$profile = is_array( $profile ) ? $profile : array();
	$row     = amz_prints_local_customer_get( $email );
	$row     = is_array( $row ) ? $row : array();
	$typed_name = trim( (string) ( $profile['name'] ?? '' ) );
	if ( $typed_name ) {
		$row['name'] = $typed_name;
	} elseif ( empty( $row['name'] ) ) {
		$row['name'] = '';
	}
	$row['email']    = $email;
	$typed_phone = trim( (string) ( $profile['phone'] ?? '' ) );
	if ( $typed_phone ) {
		$row['phone'] = $typed_phone;
	}
	if ( isset( $profile['address'] ) && '' !== trim( (string) $profile['address'] ) ) {
		$row['address'] = (string) $profile['address'];
	}
	$row['verified'] = true;
	if ( strlen( (string) $password ) >= 6 ) {
		$row['password'] = wp_hash_password( $password );
	}
	if ( $erp_token ) {
		$row['erp_token'] = (string) $erp_token;
	}
	amz_prints_local_customer_save( $email, $row );
	if ( strlen( (string) $password ) >= 6 ) {
		amz_prints_customer_production_token( $email, (string) ( $row['name'] ?? '' ), (string) ( $row['phone'] ?? '' ), (string) ( $row['address'] ?? '' ), $password, true );
	}
	$token = amz_prints_local_issue_token( $email );
	amz_prints_customer_set_token( $token );
	amz_prints_remember_portal_session( $token, array(
		'name'    => $row['name'],
		'email'   => $email,
		'phone'   => (string) ( $row['phone'] ?? '' ),
		'address' => (string) ( $row['address'] ?? '' ),
	) );
	amz_prints_customer_ensure_erp( $email );
	return $token;
}

/**
 * Create this website customer in the ERP if they are not there yet.
 *
 * @param string $email Customer email.
 */
function amz_prints_customer_ensure_erp( $email ) {
	$email = strtolower( trim( (string) $email ) );
	$row   = $email ? amz_prints_local_customer_get( $email ) : null;
	if ( ! is_array( $row ) || ! function_exists( 'amz_prints_customer_api' ) ) {
		return;
	}
	$result = amz_prints_customer_api( '/public/customer/ensure', array(
		'portalKey' => amz_prints_customer_portal_key(),
		'email'     => $email,
		'name'      => (string) ( $row['name'] ?? '' ),
		'phone'     => (string) ( $row['phone'] ?? '' ),
		'address'   => (string) ( $row['address'] ?? '' ),
	) );
	$token = amz_prints_customer_matching_erp_token( $email, $result );
	if ( $token ) {
		$row['erp_token'] = $token;
		amz_prints_local_customer_save( $email, $row );
	}
}

/**
 * True when a customer portal token is still inside its expiry window.
 *
 * @param string $token ERP customer token.
 * @return bool
 */
function amz_prints_customer_token_usable( $token ) {
	$token = (string) $token;
	if ( strlen( $token ) < 20 ) {
		return false;
	}
	$json = base64_decode( strtr( $token, '-_', '+/' ), true );
	$data = json_decode( is_string( $json ) ? $json : '', true );
	if ( ! is_array( $data ) ) {
		return false;
	}
	$kind = (string) ( $data['typ'] ?? $data['type'] ?? '' );
	if ( 'customer' !== $kind ) {
		return false;
	}
	if ( ! empty( $data['exp'] ) && (int) $data['exp'] < (int) round( microtime( true ) * 1000 ) ) {
		return false;
	}
	return true;
}

/**
 * Customer token the live ERP accepts for POST /public/orders.
 *
 * @param string $email    Customer email.
 * @param string $name     Customer name.
 * @param string $phone    Customer phone.
 * @param string $address  Customer address.
 * @param string $password Plain password when the customer just typed it.
 * @param bool   $force    Ignore a stored token and sign in again.
 * @return string
 */
function amz_prints_customer_production_token( $email, $name = '', $phone = '', $address = '', $password = '', $force = false ) {
	$email = strtolower( trim( (string) $email ) );
	if ( ! $email || ! function_exists( 'amz_prints_customer_api' ) ) {
		return '';
	}
	$row = amz_prints_local_customer_get( $email );
	$row = is_array( $row ) ? $row : array();
	$stored = (string) ( $row['erp_token'] ?? '' );
	if ( ! $force && amz_prints_customer_token_usable( $stored ) ) {
		return $stored;
	}
	$name    = trim( (string) $name ) ? trim( (string) $name ) : (string) ( $row['name'] ?? '' );
	$phone   = trim( (string) $phone ) ? trim( (string) $phone ) : (string) ( $row['phone'] ?? '' );
	$address = trim( (string) $address ) ? trim( (string) $address ) : (string) ( $row['address'] ?? '' );
	$typed   = (string) $password;
	$pass    = strlen( $typed ) >= 6 ? $typed : (string) ( $row['erp_sync_pass'] ?? '' );
	$created = false;
	if ( strlen( $pass ) < 6 ) {
		$pass    = wp_generate_password( 20, false, false );
		$created = true;
		$row['erp_sync_pass'] = $pass;
		amz_prints_local_customer_save( $email, $row );
	}
	$login = amz_prints_customer_api( '/public/customer/login', array(
		'email'    => $email,
		'password' => $pass,
	) );
	$token = amz_prints_customer_matching_erp_token( $email, $login );
	if ( ! $token && $name && $phone ) {
		$reg = amz_prints_customer_api( '/public/customer/register', array(
			'name'     => $name,
			'email'    => $email,
			'phone'    => $phone,
			'password' => $pass,
			'address'  => $address,
		) );
		$token = amz_prints_customer_matching_erp_token( $email, $reg );
	}
	if ( ! $token ) {
		return '';
	}
	$row = amz_prints_local_customer_get( $email );
	$row = is_array( $row ) ? $row : array();
	$row['erp_token'] = $token;
	if ( strlen( $pass ) >= 6 ) {
		$row['erp_sync_pass'] = $pass;
	}
	amz_prints_local_customer_save( $email, $row );
	return $token;
}

function amz_prints_customer_matching_erp_token( $email, $result ) {
	if ( is_wp_error( $result ) || empty( $result['token'] ) || ! is_array( $result['customer'] ?? null ) ) {
		return '';
	}
	$api_email = strtolower( trim( (string) ( $result['customer']['email'] ?? '' ) ) );
	if ( ! $api_email || $api_email !== strtolower( trim( (string) $email ) ) ) {
		return '';
	}
	return (string) $result['token'];
}

function amz_prints_customer_erp_token() {
	$token = amz_prints_customer_token();
	$local = amz_prints_local_session_customer( $token );
	$email = strtolower( (string) ( $local['customer']['email'] ?? '' ) );
	$row   = $email ? amz_prints_local_customer_get( $email ) : null;
	if ( is_array( $row ) && ! empty( $row['erp_token'] ) ) {
		return (string) $row['erp_token'];
	}
	return ( 0 === strpos( (string) $token, 'amzlocal.' ) ) ? '' : (string) $token;
}

function amz_prints_local_issue_token( $email ) {
	$token = 'amzlocal.' . wp_generate_password( 32, false, false );
	$sessions = get_option( 'amz_prints_local_sessions', array() );
	if ( ! is_array( $sessions ) ) {
		$sessions = array();
	}
	$sessions[ $token ] = array(
		'email' => strtolower( $email ),
		'exp'   => time() + WEEK_IN_SECONDS,
	);
	update_option( 'amz_prints_local_sessions', $sessions, false );
	return $token;
}

function amz_prints_local_session_customer( $token ) {
	if ( 0 !== strpos( (string) $token, 'amzlocal.' ) ) {
		return null;
	}
	$sessions = get_option( 'amz_prints_local_sessions', array() );
	$row      = ( is_array( $sessions ) && isset( $sessions[ $token ] ) ) ? $sessions[ $token ] : null;
	if ( ! is_array( $row ) || (int) ( $row['exp'] ?? 0 ) < time() ) {
		return null;
	}
	$customer = amz_prints_local_customer_get( $row['email'] ?? '' );
	if ( ! $customer || empty( $customer['verified'] ) ) {
		return null;
	}
	return array(
		'customer' => amz_prints_customer_card_fields( $customer ),
		'ledger'  => array(),
		'pending' => array(),
	);
}

function amz_prints_send_verify_email( $email, $name, $token ) {
	$link = add_query_arg( 'amz_verify', rawurlencode( $token ), home_url( '/customer-login/' ) );
	$body = sprintf(
		"Hello %s,\n\nConfirm your AMZ Prints account by opening this link:\n\n%s\n\nIf you did not create this account, ignore this email.\n",
		$name ? $name : 'there',
		$link
	);
	return wp_mail( $email, 'Confirm your AMZ Prints account', $body );
}

function amz_prints_customer_verify_from_request() {
	if ( empty( $_GET['amz_verify'] ) ) {
		return;
	}
	$token = sanitize_text_field( wp_unslash( $_GET['amz_verify'] ) );
	$all   = amz_prints_local_customers();
	foreach ( $all as $email => $row ) {
		if ( ! is_array( $row ) || empty( $row['verify_token'] ) || ! hash_equals( (string) $row['verify_token'], $token ) ) {
			continue;
		}
		$row['verified']    = true;
		$row['verify_token'] = '';
		amz_prints_local_customer_save( $email, $row );
		amz_prints_customer_set_token( amz_prints_local_issue_token( $email ) );
		wp_safe_redirect( amz_prints_customer_account_url() );
		exit;
	}
	wp_safe_redirect( add_query_arg( 'verify', 'invalid', home_url( '/customer-login/' ) ) );
	exit;
}
add_action( 'template_redirect', 'amz_prints_customer_verify_from_request', 1 );

function amz_prints_remember_portal_session( $token, $customer ) {
	$token = (string) $token;
	if ( ! $token ) {
		return;
	}
	$all = get_option( 'amz_prints_portal_sessions', array() );
	if ( ! is_array( $all ) ) {
		$all = array();
	}
	$all[ $token ] = array(
		'customer' => is_array( $customer ) ? $customer : array(),
		'exp'      => time() + WEEK_IN_SECONDS,
	);
	if ( count( $all ) > 40 ) {
		$all = array_slice( $all, -40, null, true );
	}
	update_option( 'amz_prints_portal_sessions', $all, false );
}

function amz_prints_portal_snapshot( $token ) {
	$all = get_option( 'amz_prints_portal_sessions', array() );
	$row = ( is_array( $all ) && isset( $all[ $token ] ) ) ? $all[ $token ] : null;
	if ( ! is_array( $row ) || (int) ( $row['exp'] ?? 0 ) < time() ) {
		return null;
	}
	return array(
		'customer'        => isset( $row['customer'] ) && is_array( $row['customer'] ) ? $row['customer'] : array(),
		'orders'          => array(),
		'invoices'        => array(),
		'discounts'       => array(),
		'ledger'          => array(),
		'pendingPayments' => array(),
	);
}

function amz_prints_store_customer_order( $email, $order ) {
	$email = strtolower( trim( (string) $email ) );
	if ( ! $email || ! is_array( $order ) ) {
		return;
	}
	$all = get_option( 'amz_prints_customer_orders', array() );
	if ( ! is_array( $all ) ) {
		$all = array();
	}
	if ( empty( $all[ $email ] ) || ! is_array( $all[ $email ] ) ) {
		$all[ $email ] = array();
	}
	$order_id = (string) ( $order['orderId'] ?? '' );
	$replaced = false;
	if ( '' !== $order_id ) {
		foreach ( $all[ $email ] as $index => $existing ) {
			if ( is_array( $existing ) && (string) ( $existing['orderId'] ?? '' ) === $order_id ) {
				$all[ $email ][ $index ] = array_merge( $existing, $order );
				$replaced = true;
				break;
			}
		}
	}
	if ( ! $replaced ) {
		$all[ $email ][] = $order;
	}
	update_option( 'amz_prints_customer_orders', $all, false );
}

function amz_prints_customer_orders_for( $email ) {
	$email = strtolower( trim( (string) $email ) );
	$all   = get_option( 'amz_prints_customer_orders', array() );
	$rows  = ( $email && is_array( $all ) && isset( $all[ $email ] ) && is_array( $all[ $email ] ) ) ? $all[ $email ] : array();
	return array_reverse( $rows );
}

/**
 * Keep website order rows in step with ERP status, payment, and products.
 *
 * @param string $email         Customer email.
 * @param array  $local_orders  Orders stored on the website.
 * @param array  $remote_orders Orders returned by the ERP session.
 * @return array
 */
function amz_prints_customer_orders_merge_remote( $email, $local_orders, $remote_orders ) {
	$local_orders  = is_array( $local_orders ) ? $local_orders : array();
	$remote_orders = is_array( $remote_orders ) ? $remote_orders : array();
	$by_id         = array();
	foreach ( $remote_orders as $remote ) {
		if ( ! is_array( $remote ) ) {
			continue;
		}
		$order_id = (string) ( $remote['orderId'] ?? '' );
		if ( '' !== $order_id ) {
			$by_id[ $order_id ] = $remote;
		}
	}
	$merged = array();
	$seen   = array();
	foreach ( $local_orders as $local_order ) {
		if ( ! is_array( $local_order ) ) {
			continue;
		}
		$order_id = (string) ( $local_order['orderId'] ?? '' );
		if ( '' !== $order_id && isset( $seen[ $order_id ] ) ) {
			continue;
		}
		if ( '' !== $order_id && isset( $by_id[ $order_id ] ) ) {
			$remote = $by_id[ $order_id ];
			foreach ( array( 'status', 'paymentStatus', 'balanceAmount', 'totalAmount', 'advancePayment', 'paymentMethod' ) as $key ) {
				if ( array_key_exists( $key, $remote ) && '' !== (string) $remote[ $key ] ) {
					$local_order[ $key ] = $remote[ $key ];
				}
			}
			if ( ! empty( $remote['products'] ) && is_array( $remote['products'] ) ) {
				$local_order['products'] = $remote['products'];
			}
			$seen[ $order_id ] = true;
		}
		$merged[] = $local_order;
	}
	foreach ( $remote_orders as $remote ) {
		if ( ! is_array( $remote ) ) {
			continue;
		}
		$order_id = (string) ( $remote['orderId'] ?? '' );
		if ( '' !== $order_id && isset( $seen[ $order_id ] ) ) {
			continue;
		}
		if ( '' !== $order_id ) {
			$seen[ $order_id ] = true;
		}
		$merged[] = $remote;
	}
	if ( $by_id && function_exists( 'amz_prints_store_customer_order' ) ) {
		foreach ( $merged as $row ) {
			$order_id = (string) ( $row['orderId'] ?? '' );
			if ( '' !== $order_id && isset( $by_id[ $order_id ] ) ) {
				amz_prints_store_customer_order( $email, $row );
			}
		}
	}
	return $merged;
}

/**
 * Last 7–10 digits of a phone number, for matching ERP rows.
 *
 * @param string $phone Raw phone.
 * @return string
 */
function amz_prints_customer_phone_key( $phone ) {
	$digits = preg_replace( '/\D+/', '', (string) $phone );
	if ( ! is_string( $digits ) || strlen( $digits ) < 7 ) {
		return '';
	}
	if ( strlen( $digits ) > 10 ) {
		$digits = substr( $digits, -10 );
	}
	return $digits;
}

/**
 * Cancelled orders use one label, whether the ERP stored the US or UK spelling.
 *
 * @param string $status ERP status.
 * @return bool
 */
function amz_prints_order_is_cancelled( $status ) {
	return (bool) preg_match( '/^cancell?ed$/i', trim( (string) $status ) );
}

/**
 * Status text to show. Every stage stays as the ERP saved it, except cancelled.
 *
 * @param string $status ERP status.
 * @return string
 */
function amz_prints_customer_status_label( $status ) {
	$status = trim( (string) $status );
	if ( '' === $status ) {
		return '';
	}
	if ( amz_prints_order_is_cancelled( $status ) ) {
		return 'Cancelled';
	}
	return $status;
}

/**
 * POS sales and quotations stay off the customer account.
 *
 * @param array $order ERP order.
 * @return bool
 */
function amz_prints_order_is_hidden_doc( $order ) {
	$doc = strtolower( trim( (string) ( $order['docType'] ?? $order['doc_type'] ?? '' ) ) );
	if ( in_array( $doc, array( 'pos', 'quotation' ), true ) ) {
		return true;
	}
	$id = strtoupper( trim( (string) ( $order['orderId'] ?? '' ) ) );
	return ( 0 === strpos( $id, 'POS-' ) || 0 === strpos( $id, 'QTN-' ) );
}

/**
 * Turn an ERP list payload into rows. Null means the request failed.
 *
 * @param array|WP_Error $data ERP response.
 * @return array|null
 */
function amz_prints_erp_rows( $data ) {
	if ( is_wp_error( $data ) || ! is_array( $data ) ) {
		return null;
	}
	if ( array() === $data ) {
		return array();
	}
	$keys    = array_keys( $data );
	$is_list = ( $keys === range( 0, count( $data ) - 1 ) );
	if ( $is_list ) {
		return $data;
	}
	foreach ( array( 'orders', 'invoices', 'payments', 'customers' ) as $key ) {
		if ( isset( $data[ $key ] ) && is_array( $data[ $key ] ) ) {
			$inner = $data[ $key ];
			$ikeys = array_keys( $inner );
			if ( array() === $inner || $ikeys === range( 0, count( $inner ) - 1 ) ) {
				return array_values( $inner );
			}
		}
	}
	return array();
}

/**
 * Staff GET, refreshing the token once if the ERP rejects it.
 *
 * @param string $path API path.
 * @return array|WP_Error
 */
function amz_prints_customer_erp_staff_get( $path ) {
	if ( ! function_exists( 'amz_prints_erp_staff_token' ) || ! function_exists( 'amz_prints_erp_request' ) ) {
		return new WP_Error( 'amz_staff', __( 'ERP sign-in is unavailable.', 'amz-prints' ) );
	}
	$token = amz_prints_erp_staff_token();
	if ( '' === $token ) {
		return new WP_Error( 'amz_staff', __( 'ERP sign-in failed.', 'amz-prints' ) );
	}
	$result = amz_prints_erp_request( 'GET', $path, null, $token );
	if ( ! is_wp_error( $result ) ) {
		return $result;
	}
	$msg  = $result->get_error_message();
	$data = $result->get_error_data();
	$code = is_array( $data ) && isset( $data['status'] ) ? (int) $data['status'] : 0;
	$auth = ( 401 === $code || false !== stripos( $msg, 'unauthorized' ) || false !== stripos( $msg, 'invalid token' ) || false !== stripos( $msg, 'login' ) );
	if ( ! $auth ) {
		return $result;
	}
	delete_transient( 'amz_erp_staff_token' );
	$token = amz_prints_erp_staff_token();
	if ( '' === $token ) {
		return $result;
	}
	return amz_prints_erp_request( 'GET', $path, null, $token );
}

/**
 * Account-shaped order from a full ERP order.
 *
 * @param array $row ERP order.
 * @return array
 */
function amz_prints_customer_normalize_erp_order( $row ) {
	$status    = amz_prints_customer_status_label( $row['status'] ?? '' );
	$cancelled = amz_prints_order_is_cancelled( $status );
	$products  = array();
	$source    = array();
	if ( ! empty( $row['products'] ) && is_array( $row['products'] ) ) {
		$source = $row['products'];
	} elseif ( ! empty( $row['items'] ) && is_array( $row['items'] ) ) {
		$source = $row['items'];
	}
	foreach ( $source as $item ) {
		if ( is_string( $item ) ) {
			$name = trim( $item );
			if ( '' !== $name ) {
				$products[] = array( 'name' => $name );
			}
			continue;
		}
		if ( ! is_array( $item ) ) {
			continue;
		}
		$name = trim( (string) ( $item['name'] ?? '' ) );
		if ( '' === $name ) {
			continue;
		}
		$products[] = array(
			'name'     => $name,
			'quantity' => (int) ( $item['quantity'] ?? $item['qty'] ?? 0 ),
			'rate'     => (float) ( $item['rate'] ?? 0 ),
			'size'     => (string) ( $item['size'] ?? '' ),
			'material' => (string) ( $item['material'] ?? '' ),
		);
	}
	return array(
		'id'              => (string) ( $row['id'] ?? '' ),
		'orderId'         => (string) ( $row['orderId'] ?? '' ),
		'trackingNumber'  => (string) ( $row['trackingNumber'] ?? '' ),
		'date'            => (string) ( $row['date'] ?? '' ),
		'status'          => $status,
		'paymentStatus'   => (string) ( $row['paymentStatus'] ?? '' ),
		'paymentMethod'   => (string) ( $row['paymentMethod'] ?? '' ),
		'advancePayment'  => $cancelled ? 0.0 : (float) ( $row['advancePayment'] ?? 0 ),
		'totalAmount'     => (float) ( $row['totalAmount'] ?? $row['total'] ?? 0 ),
		'balanceAmount'   => $cancelled ? 0.0 : (float) ( $row['balanceAmount'] ?? 0 ),
		'products'        => $products,
		'items'           => $products,
		'docType'         => (string) ( $row['docType'] ?? 'Order' ),
		'customerId'      => (string) ( $row['customerId'] ?? '' ),
		'customerEmail'   => (string) ( $row['customerEmail'] ?? '' ),
		'customerPhone'   => (string) ( $row['customerPhone'] ?? '' ),
		'erpSynced'       => 1,
		'paymentHistory'  => ( isset( $row['paymentHistory'] ) && is_array( $row['paymentHistory'] ) ) ? $row['paymentHistory'] : array(),
	);
}

/**
 * Account-shaped invoice, with a public ERP link when the invoice can be shared.
 *
 * @param array $row ERP invoice.
 * @return array
 */
function amz_prints_customer_normalize_erp_invoice( $row ) {
	$share = (string) ( $row['shareToken'] ?? '' );
	$pdf   = (string) ( $row['pdfUrl'] ?? '' );
	if ( '' === $pdf && '' !== $share ) {
		$pdf = 'https://erp.amzprints.com/invoice/' . rawurlencode( $share );
	}
	$total = (float) ( $row['totalAmount'] ?? $row['total'] ?? 0 );
	$paid  = (float) ( $row['paidAmount'] ?? $row['paid'] ?? 0 );
	$status = trim( (string) ( $row['status'] ?? '' ) );
	if ( '' === $status ) {
		if ( $paid <= 0 ) {
			$status = 'Unpaid';
		} elseif ( $total > 0 && $paid + 0.5 >= $total ) {
			$status = 'Paid';
		} else {
			$status = 'Partial';
		}
	}
	return array(
		'id'             => (string) ( $row['id'] ?? '' ),
		'invoiceNumber'  => (string) ( $row['invoiceNumber'] ?? $row['invoiceNo'] ?? '' ),
		'orderId'        => (string) ( $row['orderId'] ?? '' ),
		'date'           => (string) ( $row['date'] ?? '' ),
		'status'         => amz_prints_order_is_cancelled( $status ) ? 'Cancelled' : $status,
		'totalAmount'    => $total,
		'paidAmount'     => $paid,
		'balanceAmount'  => amz_prints_order_is_cancelled( $status ) ? 0.0 : max( 0, $total - $paid ),
		'discount'       => (float) ( $row['discount'] ?? 0 ),
		'pdfUrl'         => $pdf,
		'customerId'     => (string) ( $row['customerId'] ?? '' ),
		'customerEmail'  => (string) ( $row['customerEmail'] ?? '' ),
		'customerPhone'  => (string) ( $row['customerPhone'] ?? '' ),
	);
}

/**
 * Replace this customer's saved orders with the live list (newest last in storage).
 *
 * @param string $email  Customer email.
 * @param array  $orders Newest-first orders.
 */
function amz_prints_customer_orders_replace( $email, $orders ) {
	$email = strtolower( trim( (string) $email ) );
	if ( '' === $email ) {
		return;
	}
	$all = get_option( 'amz_prints_customer_orders', array() );
	if ( ! is_array( $all ) ) {
		$all = array();
	}
	$stored = array();
	foreach ( array_reverse( array_values( $orders ) ) as $order ) {
		if ( is_array( $order ) ) {
			$stored[] = $order;
		}
	}
	$all[ $email ] = $stored;
	update_option( 'amz_prints_customer_orders', $all, false );
}

/**
 * Live orders, invoices, payments, and ledger for the signed-in customer.
 *
 * @param array $customer     Account customer.
 * @param array $local_orders Orders already on the website.
 * @return array|null Null when the ERP list could not be read.
 */
function amz_prints_customer_erp_live_books( $customer, $local_orders ) {
	$customer     = is_array( $customer ) ? $customer : array();
	$local_orders = is_array( $local_orders ) ? $local_orders : array();
	$order_rows   = amz_prints_erp_rows( amz_prints_customer_erp_staff_get( '/orders' ) );
	if ( ! is_array( $order_rows ) ) {
		return null;
	}
	$invoice_rows  = amz_prints_erp_rows( amz_prints_customer_erp_staff_get( '/invoices' ) );
	$payment_rows  = amz_prints_erp_rows( amz_prints_customer_erp_staff_get( '/payments' ) );
	$customer_rows = amz_prints_erp_rows( amz_prints_customer_erp_staff_get( '/customers' ) );
	if ( ! is_array( $invoice_rows ) ) {
		$invoice_rows = array();
	}
	if ( ! is_array( $payment_rows ) ) {
		$payment_rows = array();
	}
	if ( ! is_array( $customer_rows ) ) {
		$customer_rows = array();
	}

	$email     = strtolower( trim( (string) ( $customer['email'] ?? '' ) ) );
	$phone_key = amz_prints_customer_phone_key( $customer['phone'] ?? '' );
	$ids       = array();
	foreach ( $customer_rows as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$cemail = strtolower( trim( (string) ( $row['email'] ?? '' ) ) );
		$cphone = amz_prints_customer_phone_key( $row['phone'] ?? '' );
		$cid    = (string) ( $row['id'] ?? '' );
		if ( '' !== $cid && ( ( $email && $cemail === $email ) || ( $phone_key && $cphone === $phone_key ) ) ) {
			$ids[ $cid ] = true;
		}
	}
	$known = array();
	foreach ( $local_orders as $local ) {
		if ( ! is_array( $local ) ) {
			continue;
		}
		foreach ( array( 'orderId', 'trackingNumber', 'id' ) as $key ) {
			$value = strtolower( trim( (string) ( $local[ $key ] ?? '' ) ) );
			if ( '' !== $value ) {
				$known[ $value ] = true;
			}
		}
	}

	$owns = function ( $row, $extra_ids = array() ) use ( $email, $phone_key, $ids, $known ) {
		if ( ! is_array( $row ) ) {
			return false;
		}
		$row_email = strtolower( trim( (string) ( $row['customerEmail'] ?? $row['email'] ?? '' ) ) );
		if ( $email && $row_email && $row_email === $email ) {
			return true;
		}
		$row_phone = amz_prints_customer_phone_key( $row['customerPhone'] ?? $row['phone'] ?? $row['partyPhone'] ?? '' );
		if ( $phone_key && $row_phone && $row_phone === $phone_key ) {
			return true;
		}
		$cid = (string) ( $row['customerId'] ?? '' );
		if ( '' !== $cid && isset( $ids[ $cid ] ) ) {
			return true;
		}
		foreach ( array( 'orderId', 'trackingNumber', 'id', 'refId', 'reference' ) as $key ) {
			$value = strtolower( trim( (string) ( $row[ $key ] ?? '' ) ) );
			if ( '' !== $value && ( isset( $known[ $value ] ) || isset( $extra_ids[ $value ] ) ) ) {
				return true;
			}
		}
		return false;
	};

	$erp_orders = array();
	$order_ids  = array();
	foreach ( $order_rows as $row ) {
		if ( ! is_array( $row ) || amz_prints_order_is_hidden_doc( $row ) || ! $owns( $row ) ) {
			continue;
		}
		$order = amz_prints_customer_normalize_erp_order( $row );
		if ( '' === $order['orderId'] && '' === $order['id'] ) {
			continue;
		}
		$erp_orders[] = $order;
		foreach ( array( 'orderId', 'trackingNumber', 'id' ) as $key ) {
			$value = strtolower( trim( (string) ( $order[ $key ] ?? '' ) ) );
			if ( '' !== $value ) {
				$order_ids[ $value ] = true;
			}
		}
	}

	$invoices = array();
	foreach ( $invoice_rows as $row ) {
		if ( ! is_array( $row ) || ! $owns( $row, $order_ids ) ) {
			continue;
		}
		$invoice = amz_prints_customer_normalize_erp_invoice( $row );
		if ( '' === $invoice['invoiceNumber'] && '' === $invoice['id'] ) {
			continue;
		}
		$invoices[] = $invoice;
	}

	$invoice_ids = array();
	foreach ( $invoices as $invoice ) {
		foreach ( array( 'invoiceNumber', 'id', 'orderId' ) as $key ) {
			$value = strtolower( trim( (string) ( $invoice[ $key ] ?? '' ) ) );
			if ( '' !== $value ) {
				$invoice_ids[ $value ] = true;
			}
		}
	}

	$pay_lines = array();
	foreach ( $payment_rows as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$type = strtolower( trim( (string) ( $row['type'] ?? 'inflow' ) ) );
		if ( 'outflow' === $type || 'out' === $type ) {
			continue;
		}
		if ( ! $owns( $row, $order_ids + $invoice_ids ) ) {
			continue;
		}
		$amount = (float) ( $row['amount'] ?? 0 );
		if ( $amount <= 0 ) {
			continue;
		}
		$ref = (string) ( $row['refId'] ?? $row['reference'] ?? '' );
		$pay_lines[] = array(
			'date'      => (string) ( $row['date'] ?? '' ),
			'method'    => (string) ( $row['method'] ?? '' ),
			'reference' => $ref,
			'amount'    => $amount,
			'notes'     => (string) ( $row['notes'] ?? '' ),
		);
	}

	if ( ! $pay_lines ) {
		$advance_orders = array();
		foreach ( $erp_orders as $order ) {
			if ( amz_prints_order_is_cancelled( $order['status'] ?? '' ) ) {
				continue;
			}
			$advance = (float) ( $order['advancePayment'] ?? 0 );
			$ref     = (string) ( $order['orderId'] ?? '' );
			if ( $advance <= 0 || '' === $ref ) {
				continue;
			}
			$advance_orders[ strtolower( $ref ) ] = true;
			$pay_lines[] = array(
				'date'      => (string) ( $order['date'] ?? '' ),
				'method'    => (string) ( $order['paymentMethod'] ?? '' ),
				'reference' => $ref,
				'amount'    => $advance,
				'notes'     => __( 'Advance on this order', 'amz-prints' ),
			);
		}
		foreach ( $invoices as $invoice ) {
			if ( amz_prints_order_is_cancelled( $invoice['status'] ?? '' ) ) {
				continue;
			}
			$paid     = (float) ( $invoice['paidAmount'] ?? 0 );
			$ref      = (string) ( $invoice['invoiceNumber'] ?? '' );
			$order_id = strtolower( trim( (string) ( $invoice['orderId'] ?? '' ) ) );
			if ( $paid <= 0 || '' === $ref || isset( $advance_orders[ $order_id ] ) ) {
				continue;
			}
			$pay_lines[] = array(
				'date'      => (string) ( $invoice['date'] ?? '' ),
				'method'    => __( 'Invoice', 'amz-prints' ),
				'reference' => $ref,
				'amount'    => $paid,
				'notes'     => __( 'Recorded on the invoice', 'amz-prints' ),
			);
		}
	}

	usort(
		$pay_lines,
		function ( $a, $b ) {
			return strcmp( (string) ( $b['date'] ?? '' ), (string) ( $a['date'] ?? '' ) );
		}
	);

	$seen    = array();
	$display = array();
	foreach ( $erp_orders as $order ) {
		$key = strtolower( (string) ( $order['orderId'] ?? $order['id'] ?? '' ) );
		if ( '' !== $key && isset( $seen[ $key ] ) ) {
			continue;
		}
		if ( '' !== $key ) {
			$seen[ $key ] = true;
		}
		$display[] = $order;
	}
	foreach ( $local_orders as $local ) {
		if ( ! is_array( $local ) ) {
			continue;
		}
		$key = strtolower( (string) ( $local['orderId'] ?? $local['id'] ?? '' ) );
		if ( '' !== $key && isset( $seen[ $key ] ) ) {
			continue;
		}
		if ( '' !== $key ) {
			$seen[ $key ] = true;
		}
		if ( ! empty( $local['status'] ) ) {
			$local['status'] = amz_prints_customer_status_label( $local['status'] );
		}
		$display[] = $local;
	}
	usort(
		$display,
		function ( $a, $b ) {
			return strcmp( (string) ( $b['date'] ?? '' ), (string) ( $a['date'] ?? '' ) );
		}
	);
	usort(
		$invoices,
		function ( $a, $b ) {
			return strcmp( (string) ( $b['date'] ?? '' ), (string) ( $a['date'] ?? '' ) );
		}
	);

	$billed       = 0.0;
	$outstanding  = 0.0;
	$pending      = array();
	foreach ( $display as $order ) {
		if ( ! is_array( $order ) || amz_prints_order_is_cancelled( $order['status'] ?? '' ) ) {
			continue;
		}
		$total   = (float) ( $order['totalAmount'] ?? 0 );
		$balance = max( 0, (float) ( $order['balanceAmount'] ?? 0 ) );
		$billed      += $total;
		$outstanding += $balance;
		if ( $balance > 0 ) {
			$pending[] = array(
				'source' => 'order',
				'ref'    => (string) ( $order['orderId'] ?? $order['id'] ?? '' ),
				'date'   => (string) ( $order['date'] ?? '' ),
				'amount' => $balance,
				'status' => (string) ( $order['status'] ?? '' ),
			);
		}
	}
	$discount_items = array();
	$total_discount = 0.0;
	foreach ( $invoices as $invoice ) {
		$due = (float) ( $invoice['balanceAmount'] ?? 0 );
		if ( $due > 0 && ! amz_prints_order_is_cancelled( $invoice['status'] ?? '' ) ) {
			$pending[] = array(
				'source' => 'invoice',
				'ref'    => (string) ( $invoice['invoiceNumber'] ?? $invoice['id'] ?? '' ),
				'date'   => (string) ( $invoice['date'] ?? '' ),
				'amount' => $due,
				'status' => (string) ( $invoice['status'] ?? '' ),
			);
		}
		$discount = (float) ( $invoice['discount'] ?? 0 );
		if ( $discount > 0 ) {
			$total_discount += $discount;
			$discount_items[] = array(
				'invoiceNumber' => (string) ( $invoice['invoiceNumber'] ?? '' ),
				'date'          => (string) ( $invoice['date'] ?? '' ),
				'discount'      => $discount,
				'totalAmount'   => (float) ( $invoice['totalAmount'] ?? 0 ),
				'status'        => (string) ( $invoice['status'] ?? '' ),
				'pdfUrl'        => (string) ( $invoice['pdfUrl'] ?? '' ),
			);
		}
	}

	if ( $email ) {
		amz_prints_customer_orders_replace( $email, $display );
	}

	return array(
		'orders'          => $display,
		'invoices'        => $invoices,
		'ledger'          => array(
			'totalBilled' => $billed,
			'totalPaid'   => max( 0, $billed - $outstanding ),
			'outstanding' => $outstanding,
			'payments'    => $pay_lines,
		),
		'pendingPayments' => $pending,
		'discounts'       => array(
			'totalDiscount' => $total_discount,
			'count'         => count( $discount_items ),
			'items'         => $discount_items,
		),
	);
}

/**
 * Overlay the open account with the current ERP books.
 *
 * @param array|WP_Error $session Account session.
 * @return array|WP_Error
 */
function amz_prints_customer_apply_live_books( $session ) {
	if ( is_wp_error( $session ) || ! is_array( $session ) ) {
		return $session;
	}
	$books = amz_prints_customer_erp_live_books(
		isset( $session['customer'] ) && is_array( $session['customer'] ) ? $session['customer'] : array(),
		isset( $session['orders'] ) && is_array( $session['orders'] ) ? $session['orders'] : array()
	);
	if ( ! is_array( $books ) ) {
		$session['erpLive'] = false;
		return $session;
	}
	$session['orders']          = $books['orders'];
	$session['invoices']        = $books['invoices'];
	$session['ledger']          = $books['ledger'];
	$session['pendingPayments'] = $books['pendingPayments'];
	$session['discounts']       = $books['discounts'];
	$session['erpLive']         = true;
	return $session;
}

function amz_prints_customer_fetch_session() {
	$token = amz_prints_customer_token();
	if ( ! $token || 0 !== strpos( (string) $token, 'amzlocal.' ) ) {
		if ( $token ) {
			amz_prints_customer_clear_token();
		}
		return new WP_Error( 'amz_customer_auth', __( 'Please log in.', 'amz-prints' ) );
	}
	$local = amz_prints_local_session_customer( $token );
	if ( ! $local ) {
		amz_prints_customer_clear_token();
		return new WP_Error( 'amz_customer_auth', __( 'Please log in again.', 'amz-prints' ) );
	}
	$email = strtolower( trim( (string) ( $local['customer']['email'] ?? '' ) ) );
	$row   = $email ? amz_prints_local_customer_get( $email ) : null;
	if ( ! is_array( $row ) || strtolower( trim( (string) ( $row['email'] ?? '' ) ) ) !== $email ) {
		amz_prints_customer_clear_token();
		return new WP_Error( 'amz_customer_auth', __( 'Please log in again.', 'amz-prints' ) );
	}
	$local['customer'] = amz_prints_customer_card_fields( $row );
	$local['orders']                 = amz_prints_customer_orders_for( $email );
	$local['invoices']               = array();
	$local['ledger']                 = array(
		'totalBilled'  => 0,
		'totalPaid'    => 0,
		'outstanding'  => 0,
		'payments'     => array(),
	);
	$local['pendingPayments']        = array();

	$erp = (string) ( $row['erp_token'] ?? '' );
	if ( $erp ) {
		$remote = amz_prints_customer_api( '/public/customer/session', array( 'token' => $erp ) );
		if ( ! is_wp_error( $remote ) && is_array( $remote ) ) {
			$remote_email = strtolower( trim( (string) ( $remote['customer']['email'] ?? '' ) ) );
			if ( $remote_email === $email ) {
				$remote_orders = isset( $remote['orders'] ) && is_array( $remote['orders'] ) ? $remote['orders'] : array();
				$local['orders'] = amz_prints_customer_orders_merge_remote( $email, $local['orders'], $remote_orders );
				if ( ! empty( $remote['invoices'] ) && is_array( $remote['invoices'] ) ) {
					$local['invoices'] = $remote['invoices'];
				}
				if ( ! empty( $remote['ledger'] ) && is_array( $remote['ledger'] ) ) {
					$local['ledger'] = $remote['ledger'];
				}
				if ( ! empty( $remote['pendingPayments'] ) && is_array( $remote['pendingPayments'] ) ) {
					$local['pendingPayments'] = $remote['pendingPayments'];
				}
				if ( ! empty( $remote['discounts'] ) ) {
					$local['discounts'] = $remote['discounts'];
				}
			}
		}
	}
	return $local;
}

/**
 * AJAX: does this email already have a customer account?
 */
function amz_prints_ajax_customer_lookup() {
	check_ajax_referer( 'amz_prints_customer', 'nonce' );
	$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	if ( ! $email || ! is_email( $email ) ) {
		wp_send_json_error( array( 'message' => __( 'Enter a valid email address.', 'amz-prints' ) ), 400 );
	}
	$local = amz_prints_local_customer_get( $email );
	if ( $local && ! empty( $local['verified'] ) && ! empty( $local['password'] ) ) {
		wp_send_json_success( array(
			'exists'      => true,
			'hasPassword' => true,
		) );
	}
	$result = amz_prints_customer_api( '/public/customer/lookup', array( 'email' => $email ) );
	if ( is_wp_error( $result ) ) {
		wp_send_json_success( array(
			'exists'      => false,
			'hasPassword' => false,
		) );
	}
	wp_send_json_success( array(
		'exists'      => ! empty( $result['exists'] ),
		'hasPassword' => ! empty( $result['hasPassword'] ),
	) );
}
add_action( 'wp_ajax_amz_prints_customer_lookup', 'amz_prints_ajax_customer_lookup' );
add_action( 'wp_ajax_nopriv_amz_prints_customer_lookup', 'amz_prints_ajax_customer_lookup' );

/**
 * AJAX: create new customer account
 */
function amz_prints_ajax_customer_register() {
	check_ajax_referer( 'amz_prints_customer', 'nonce' );
	$name     = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$email    = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$phone    = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
	$password = isset( $_POST['password'] ) ? (string) wp_unslash( $_POST['password'] ) : '';
	$address  = isset( $_POST['address'] ) ? sanitize_textarea_field( wp_unslash( $_POST['address'] ) ) : '';
	$identity = amz_prints_customer_validate_identity( $name, $email, $phone, $address, true );
	if ( is_wp_error( $identity ) ) {
		wp_send_json_error( array( 'message' => $identity->get_error_message() ), 400 );
	}
	$name    = $identity['name'];
	$email   = $identity['email'];
	$phone   = $identity['phone'];
	$address = $identity['address'];

	if ( strlen( $password ) < 6 ) {
		wp_send_json_error( array( 'message' => __( 'Password must be at least 6 characters.', 'amz-prints' ) ), 400 );
	}

	$existing_local = amz_prints_local_customer_get( $email );
	if ( $existing_local && ! empty( $existing_local['verified'] ) ) {
		wp_send_json_error( array(
			'message' => __( 'An account already exists for this email. Please log in.', 'amz-prints' ),
			'code'    => 'need_login',
		), 400 );
	}

	$result = amz_prints_customer_api( '/public/customer/register', array(
		'name'     => $name,
		'email'    => $email,
		'phone'    => $phone,
		'password' => $password,
		'address'  => $address,
	) );
	if ( is_wp_error( $result ) ) {
		$err = $result->get_error_message();
		if ( false !== stripos( $err, 'please log in' ) || false !== stripos( $err, 'already exists' ) ) {
			$login = amz_prints_customer_api( '/public/customer/login', array(
				'email'    => $email,
				'password' => $password,
			) );
			if ( ! is_wp_error( $login ) && ! empty( $login['token'] ) ) {
				amz_prints_customer_sign_in_local( $email, array( 'name' => $name, 'phone' => $phone, 'address' => $address ), $password, amz_prints_customer_matching_erp_token( $email, $login ) );
				wp_send_json_success( array(
					'redirect' => amz_prints_customer_redirect_from_post(),
					'message'  => __( 'This email already had an account. You are signed in.', 'amz-prints' ),
				) );
			}
			$login_err = is_wp_error( $login ) ? $login->get_error_message() : '';
			if ( false !== stripos( $login_err, 'not set' ) || false !== stripos( $login_err, 'not registered' ) || false !== stripos( $login_err, 'not found' ) || false !== stripos( $login_err, 'sign up' ) ) {
				amz_prints_customer_sign_in_local( $email, array( 'name' => $name, 'phone' => $phone, 'address' => $address ), $password );
				wp_send_json_success( array(
					'redirect' => amz_prints_customer_redirect_from_post(),
					'created'  => true,
					'message'  => __( 'Account created. You are signed in.', 'amz-prints' ),
				) );
			}
			wp_send_json_error( array(
				'message' => __( 'This email already has an account, and that password does not match. Open Log in, or use Continue with Google.', 'amz-prints' ),
				'code'    => 'need_login',
			), 400 );
		}
		amz_prints_customer_sign_in_local( $email, array( 'name' => $name, 'phone' => $phone, 'address' => $address ), $password );
		wp_send_json_success( array(
			'redirect' => amz_prints_customer_redirect_from_post(),
			'created'  => true,
			'message'  => __( 'Account created. You are signed in.', 'amz-prints' ),
		) );
	}
	if ( empty( $result['token'] ) ) {
		wp_send_json_error( array( 'message' => __( 'The ERP did not create this account. Check name, email, and phone, then try again.', 'amz-prints' ) ), 400 );
	}

	amz_prints_customer_sign_in_local(
		$email,
		array( 'name' => $name, 'phone' => $phone, 'address' => $address ),
		$password,
		amz_prints_customer_matching_erp_token( $email, $result )
	);
	$redirect = isset( $_POST['redirect'] ) ? esc_url_raw( wp_unslash( $_POST['redirect'] ) ) : '';
	$redirect = $redirect ? wp_validate_redirect( $redirect, amz_prints_customer_account_url() ) : amz_prints_customer_account_url();
	wp_send_json_success( array(
		'customer' => isset( $result['customer'] ) ? $result['customer'] : array(),
		'redirect' => $redirect,
		'created'  => true,
		'message'  => __( 'Account created. You are signed in.', 'amz-prints' ),
	) );
}
add_action( 'wp_ajax_amz_prints_customer_register', 'amz_prints_ajax_customer_register' );
add_action( 'wp_ajax_nopriv_amz_prints_customer_register', 'amz_prints_ajax_customer_register' );

/**
 * AJAX: email/password login
 */
function amz_prints_ajax_customer_login() {
	check_ajax_referer( 'amz_prints_customer', 'nonce' );
	$email    = isset( $_POST['email'] ) ? strtolower( sanitize_email( wp_unslash( $_POST['email'] ) ) ) : '';
	$password = isset( $_POST['password'] ) ? (string) wp_unslash( $_POST['password'] ) : '';
	if ( ! is_email( $email ) ) {
		wp_send_json_error( array( 'message' => __( 'Enter a correct email address.', 'amz-prints' ) ), 400 );
	}

	$redirect = isset( $_POST['redirect'] ) ? esc_url_raw( wp_unslash( $_POST['redirect'] ) ) : '';
	$redirect = $redirect ? wp_validate_redirect( $redirect, amz_prints_customer_account_url() ) : amz_prints_customer_account_url();

	$local = amz_prints_local_customer_get( $email );
	if ( $local && ! empty( $local['password'] ) && wp_check_password( $password, $local['password'] ) ) {
		amz_prints_customer_sign_in_local(
			$email,
			array(
				'name'    => (string) ( $local['name'] ?? '' ),
				'phone'   => (string) ( $local['phone'] ?? '' ),
				'address' => (string) ( $local['address'] ?? '' ),
			),
			$password
		);
		wp_send_json_success( array(
			'redirect' => $redirect,
			'customer' => array(
				'name'    => (string) ( $local['name'] ?? '' ),
				'email'   => $email,
				'phone'   => (string) ( $local['phone'] ?? '' ),
				'address' => (string) ( $local['address'] ?? '' ),
			),
		) );
	}

	$result = amz_prints_customer_api( '/public/customer/login', array(
		'email'    => $email,
		'password' => $password,
	) );
	if ( is_wp_error( $result ) ) {
		$err  = $result->get_error_message();
		$code = '';
		if ( false !== stripos( $err, 'please sign up' ) || false !== stripos( $err, 'no customer account' ) || false !== stripos( $err, 'not registered online' ) || 'Not found' === $err || false !== stripos( $err, 'not found' ) ) {
			$code = 'need_signup';
			$err  = __( 'No account for this email. Create an account with your name, email, mobile number, and delivery address.', 'amz-prints' );
		} elseif ( false !== stripos( $err, 'invalid email' ) || false !== stripos( $err, 'invalid password' ) || false !== stripos( $err, 'invalid credential' ) ) {
			$err = __( 'That email and password do not match. Use the password from Sign up.', 'amz-prints' );
		}
		wp_send_json_error( array( 'message' => $err, 'code' => $code ), 400 );
	}
	if ( empty( $result['token'] ) ) {
		wp_send_json_error( array( 'message' => __( 'Login failed.', 'amz-prints' ) ), 400 );
	}
	$cust      = isset( $result['customer'] ) && is_array( $result['customer'] ) ? $result['customer'] : array();
	$api_email = strtolower( trim( (string) ( $cust['email'] ?? '' ) ) );
	if ( $api_email !== $email ) {
		wp_send_json_error( array(
			'message' => __( 'This login did not match your email. Create your own account and sign in with that email.', 'amz-prints' ),
			'code'    => 'need_signup',
		), 400 );
	}
	$profile = array(
		'name'    => (string) ( $local['name'] ?? '' ),
		'phone'   => (string) ( $local['phone'] ?? '' ),
		'address' => (string) ( $local['address'] ?? '' ),
	);
	if ( '' === trim( $profile['name'] ) ) {
		$profile['name'] = (string) ( $cust['name'] ?? '' );
	}
	if ( '' === trim( $profile['phone'] ) ) {
		$profile['phone'] = (string) ( $cust['phone'] ?? '' );
	}
	if ( '' === trim( $profile['address'] ) ) {
		$profile['address'] = (string) ( $cust['address'] ?? '' );
	}
	amz_prints_customer_sign_in_local( $email, $profile, $password, amz_prints_customer_matching_erp_token( $email, $result ) );
	wp_send_json_success( array(
		'customer' => array(
			'name'    => $profile['name'],
			'email'   => $email,
			'phone'   => $profile['phone'],
			'address' => $profile['address'],
		),
		'redirect' => $redirect,
	) );
}
add_action( 'wp_ajax_amz_prints_customer_login', 'amz_prints_ajax_customer_login' );
add_action( 'wp_ajax_nopriv_amz_prints_customer_login', 'amz_prints_ajax_customer_login' );

/**
 * AJAX: Google verify login / password reset
 * Google token is verified in WordPress; ERP receives email + portalKey (no UrlFetchApp).
 */
function amz_prints_ajax_customer_google() {
	check_ajax_referer( 'amz_prints_customer', 'nonce' );
	$id_token     = isset( $_POST['id_token'] ) ? (string) wp_unslash( $_POST['id_token'] ) : '';
	$new_password = isset( $_POST['new_password'] ) ? (string) wp_unslash( $_POST['new_password'] ) : '';

	$google = amz_prints_verify_google_id_token( $id_token );
	if ( is_wp_error( $google ) ) {
		wp_send_json_error( array( 'message' => $google->get_error_message() ), 400 );
	}

	$phone = isset( $_POST['phone'] ) ? amz_prints_customer_normalize_phone( sanitize_text_field( wp_unslash( $_POST['phone'] ) ) ) : '';
	if ( $phone && amz_prints_customer_phone_error( $phone ) ) {
		wp_send_json_error( array( 'message' => amz_prints_customer_phone_error( $phone ) ), 400 );
	}
	$gname = $google['name'] ? $google['name'] : ( isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '' );
	$typed = isset( $_POST['password'] ) ? (string) wp_unslash( $_POST['password'] ) : '';
	$pass  = strlen( $typed ) >= 6 ? $typed : ( strlen( $new_password ) >= 6 ? $new_password : wp_generate_password( 16, false, false ) );

	$body = array(
		'googleVerified'  => true,
		'email'           => $google['email'],
		'name'            => $gname,
		'phone'           => $phone,
		'password'        => $pass,
		'portalKey'       => amz_prints_customer_portal_key(),
		'createIfMissing' => true,
	);
	if ( $new_password ) {
		$body['newPassword'] = $new_password;
	}

	$result = amz_prints_customer_api( '/public/customer/google', $body );
	if ( is_wp_error( $result ) || empty( $result['token'] ) ) {
		$made = null;
		if ( $phone && $gname ) {
			$made = amz_prints_customer_api( '/public/customer/register', array(
				'name'     => $gname,
				'email'    => $google['email'],
				'phone'    => $phone,
				'password' => $pass,
			) );
		}
		if ( ! is_wp_error( $made ) && is_array( $made ) && ! empty( $made['token'] ) ) {
			amz_prints_customer_sign_in_local( $google['email'], array( 'name' => $gname, 'phone' => $phone ), $pass, amz_prints_customer_matching_erp_token( $google['email'], $made ) );
			wp_send_json_success( array(
				'redirect' => amz_prints_customer_redirect_from_post(),
				'created'  => true,
				'message'  => __( 'Google verified. Your account is created and you are signed in.', 'amz-prints' ),
			) );
		}
		amz_prints_customer_sign_in_local( $google['email'], array(
			'name'  => $gname ? $gname : $google['email'],
			'phone' => $phone,
		), $pass );
		wp_send_json_success( array(
			'redirect' => amz_prints_customer_redirect_from_post(),
			'created'  => true,
			'message'  => __( 'Google verified. You are signed in.', 'amz-prints' ),
		) );
	}
	amz_prints_customer_sign_in_local( $google['email'], array( 'name' => $gname, 'phone' => $phone ), $pass, amz_prints_customer_matching_erp_token( $google['email'], $result ) );
	$redirect = isset( $_POST['redirect'] ) ? esc_url_raw( wp_unslash( $_POST['redirect'] ) ) : '';
	$redirect = $redirect ? wp_validate_redirect( $redirect, amz_prints_customer_account_url() ) : amz_prints_customer_account_url();
	wp_send_json_success( array(
		'customer'        => isset( $result['customer'] ) ? $result['customer'] : array(),
		'passwordUpdated' => ! empty( $result['passwordUpdated'] ),
		'created'         => ! empty( $result['created'] ),
		'redirect'        => $redirect,
	) );
}
add_action( 'wp_ajax_amz_prints_customer_google', 'amz_prints_ajax_customer_google' );
add_action( 'wp_ajax_nopriv_amz_prints_customer_google', 'amz_prints_ajax_customer_google' );

/**
 * AJAX: send password-reset verification code to customer email.
 */
function amz_prints_ajax_customer_reset_request() {
	check_ajax_referer( 'amz_prints_customer', 'nonce' );
	$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	if ( ! $email || ! is_email( $email ) ) {
		wp_send_json_error( array( 'message' => __( 'Enter a valid email address.', 'amz-prints' ) ), 400 );
	}
	$email_key = strtolower( $email );
	$cool_key  = 'amz_pwreset_cool_' . md5( $email_key );
	if ( get_transient( $cool_key ) ) {
		wp_send_json_error( array( 'message' => __( 'Please wait a minute before requesting another code.', 'amz-prints' ) ), 429 );
	}

	$code = (string) wp_rand( 100000, 999999 );
	set_transient(
		'amz_pwreset_' . md5( $email_key ),
		array(
			'code'  => $code,
			'email' => $email_key,
			'tries' => 0,
		),
		15 * MINUTE_IN_SECONDS
	);
	set_transient( $cool_key, 1, MINUTE_IN_SECONDS );

	$company = amz_prints_mod( 'amz_company_name', 'AMZ Prints' );
	$subject = sprintf( '[%s] Password reset code', $company );
	$body    = sprintf(
		"Your %s password reset code is:\n\n%s\n\nThis code expires in 15 minutes. If you did not request a reset, ignore this email.\n",
		$company,
		$code
	);
	$sent = wp_mail( $email, $subject, $body );
	if ( ! $sent ) {
		wp_send_json_error( array( 'message' => __( 'Could not send email. Try again or contact AMZ Prints.', 'amz-prints' ) ), 500 );
	}
	wp_send_json_success( array(
		'message' => __( 'We sent a 6-digit code to your email. Enter it below to set a new password.', 'amz-prints' ),
	) );
}
add_action( 'wp_ajax_amz_prints_customer_reset_request', 'amz_prints_ajax_customer_reset_request' );
add_action( 'wp_ajax_nopriv_amz_prints_customer_reset_request', 'amz_prints_ajax_customer_reset_request' );

/**
 * AJAX: confirm email code and set a new password.
 */
function amz_prints_ajax_customer_reset_confirm() {
	check_ajax_referer( 'amz_prints_customer', 'nonce' );
	$email    = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$code     = isset( $_POST['code'] ) ? preg_replace( '/\D+/', '', (string) wp_unslash( $_POST['code'] ) ) : '';
	$password = isset( $_POST['new_password'] ) ? (string) wp_unslash( $_POST['new_password'] ) : '';
	if ( ! $email || ! is_email( $email ) ) {
		wp_send_json_error( array( 'message' => __( 'Enter a valid email address.', 'amz-prints' ) ), 400 );
	}
	if ( strlen( $code ) !== 6 ) {
		wp_send_json_error( array( 'message' => __( 'Enter the 6-digit verification code.', 'amz-prints' ) ), 400 );
	}
	if ( strlen( $password ) < 6 ) {
		wp_send_json_error( array( 'message' => __( 'Password must be at least 6 characters.', 'amz-prints' ) ), 400 );
	}
	$key  = 'amz_pwreset_' . md5( strtolower( $email ) );
	$data = get_transient( $key );
	if ( ! is_array( $data ) || empty( $data['code'] ) ) {
		wp_send_json_error( array( 'message' => __( 'Code expired. Request a new verification code.', 'amz-prints' ) ), 400 );
	}
	$tries = isset( $data['tries'] ) ? (int) $data['tries'] : 0;
	if ( $tries >= 5 ) {
		delete_transient( $key );
		wp_send_json_error( array( 'message' => __( 'Too many attempts. Request a new code.', 'amz-prints' ) ), 400 );
	}
	if ( ! hash_equals( (string) $data['code'], (string) $code ) ) {
		$data['tries'] = $tries + 1;
		set_transient( $key, $data, 15 * MINUTE_IN_SECONDS );
		wp_send_json_error( array( 'message' => __( 'Incorrect verification code.', 'amz-prints' ) ), 400 );
	}

	$result = amz_prints_customer_api(
		'/public/customer/reset-password',
		array(
			'email'       => strtolower( $email ),
			'newPassword' => $password,
			'portalKey'   => amz_prints_customer_portal_key(),
			'resetVerified' => true,
		)
	);
	if ( is_wp_error( $result ) ) {
		$local = amz_prints_local_customer_get( $email );
		$msg   = $result->get_error_message();
		if ( $local && ( 'Not found' === $msg || false !== stripos( $msg, 'not found' ) ) ) {
			amz_prints_local_customer_save( $email, array_merge( $local, array(
				'password' => wp_hash_password( $password ),
				'verified' => true,
			) ) );
			$token = amz_prints_local_issue_token( $email );
			amz_prints_customer_set_token( $token );
			amz_prints_remember_portal_session( $token, array(
				'name'  => (string) ( $local['name'] ?? '' ),
				'email' => $email,
				'phone' => (string) ( $local['phone'] ?? '' ),
			) );
			delete_transient( $key );
			$redirect = isset( $_POST['redirect'] ) ? esc_url_raw( wp_unslash( $_POST['redirect'] ) ) : '';
			$redirect = $redirect ? wp_validate_redirect( $redirect, amz_prints_customer_account_url() ) : amz_prints_customer_account_url();
			wp_send_json_success( array(
				'message'  => __( 'Password updated. You are signed in.', 'amz-prints' ),
				'redirect' => $redirect,
			) );
		}
		wp_send_json_error( array( 'message' => $msg ), 400 );
	}
	delete_transient( $key );
	if ( ! empty( $result['token'] ) ) {
		$reset_customer = isset( $result['customer'] ) && is_array( $result['customer'] ) ? $result['customer'] : array();
		$saved_local    = amz_prints_local_customer_get( $email );
		$saved_local    = is_array( $saved_local ) ? $saved_local : array();
		amz_prints_customer_sign_in_local( $email, array(
			'name'    => (string) ( $saved_local['name'] ?? '' ) !== '' ? (string) $saved_local['name'] : (string) ( $reset_customer['name'] ?? '' ),
			'phone'   => (string) ( $saved_local['phone'] ?? '' ) !== '' ? (string) $saved_local['phone'] : (string) ( $reset_customer['phone'] ?? '' ),
			'address' => (string) ( $saved_local['address'] ?? '' ),
		), $password, amz_prints_customer_matching_erp_token( $email, $result ) );
	}
	$redirect = isset( $_POST['redirect'] ) ? esc_url_raw( wp_unslash( $_POST['redirect'] ) ) : '';
	$redirect = $redirect ? wp_validate_redirect( $redirect, amz_prints_customer_account_url() ) : amz_prints_customer_account_url();
	wp_send_json_success( array(
		'message'  => __( 'Password updated.', 'amz-prints' ),
		'redirect' => $redirect,
	) );
}
add_action( 'wp_ajax_amz_prints_customer_reset_confirm', 'amz_prints_ajax_customer_reset_confirm' );
add_action( 'wp_ajax_nopriv_amz_prints_customer_reset_confirm', 'amz_prints_ajax_customer_reset_confirm' );

/**
 * AJAX: logout
 */
function amz_prints_ajax_customer_logout() {
	check_ajax_referer( 'amz_prints_customer', 'nonce' );
	amz_prints_customer_clear_token();
	wp_send_json_success( array( 'redirect' => amz_prints_customer_login_url() ) );
}
add_action( 'wp_ajax_amz_prints_customer_logout', 'amz_prints_ajax_customer_logout' );
add_action( 'wp_ajax_nopriv_amz_prints_customer_logout', 'amz_prints_ajax_customer_logout' );

/**
 * AJAX: public order tracking. No account required.
 */
function amz_prints_ajax_customer_track() {
	check_ajax_referer( 'amz_prints_customer', 'nonce' );
	$code   = isset( $_POST['code'] ) ? sanitize_text_field( wp_unslash( $_POST['code'] ) ) : '';
	$result = function_exists( 'amz_prints_public_track' ) ? amz_prints_public_track( $code ) : new WP_Error( 'amz_track', __( 'Tracking is not available right now.', 'amz-prints' ) );
	if ( is_wp_error( $result ) ) {
		wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 );
	}
	$products = array();
	foreach ( (array) ( $result['products'] ?? array() ) as $name ) {
		$name = trim( (string) $name );
		if ( $name ) {
			$products[] = array( 'name' => $name );
		}
	}
	wp_send_json_success( array(
		'orderId'         => (string) ( $result['order_id'] ?? '' ),
		'trackingNumber'  => (string) ( $result['tracking_number'] ?? '' ),
		'status'          => (string) ( $result['status'] ?? '' ),
		'cancelled'       => ! empty( $result['cancelled'] ),
		'paymentStatus'   => (string) ( $result['payment_status'] ?? '' ),
		'paymentMethod'   => (string) ( $result['payment_method'] ?? '' ),
		'totalAmount'     => isset( $result['total_amount'] ) && null !== $result['total_amount'] ? (float) $result['total_amount'] : null,
		'balanceAmount'   => isset( $result['balance_amount'] ) && null !== $result['balance_amount'] ? (float) $result['balance_amount'] : null,
		'customerName'    => (string) ( $result['customer'] ?? '' ),
		'products'        => $products,
		'timeline'        => isset( $result['timeline'] ) && is_array( $result['timeline'] ) ? $result['timeline'] : array(),
	) );
}

/**
 * Fields shown on the account form and loyalty card.
 *
 * @param array $row Saved customer row.
 * @return array
 */
function amz_prints_customer_card_fields( $row ) {
	$row   = is_array( $row ) ? $row : array();
	$email = strtolower( trim( (string) ( $row['email'] ?? '' ) ) );
	return array(
		'name'       => (string) ( $row['name'] ?? '' ),
		'email'      => $email,
		'phone'      => (string) ( $row['phone'] ?? '' ),
		'address'    => (string) ( $row['address'] ?? '' ),
		'street'     => (string) ( $row['street'] ?? '' ),
		'area'       => (string) ( $row['area'] ?? '' ),
		'city'       => (string) ( $row['city'] ?? '' ),
		'postal'     => (string) ( $row['postal'] ?? '' ),
		'landmark'   => (string) ( $row['landmark'] ?? '' ),
		'photo'      => (string) ( $row['photo'] ?? '' ),
		'cardNumber' => 'AMZ-' . strtoupper( substr( md5( $email ), 0, 6 ) ),
	);
}

/**
 * Delivered online spend for the loyalty card.
 *
 * @param array $orders Orders for this email.
 * @return float
 */
function amz_prints_loyalty_delivered_total( $orders ) {
	$total = 0.0;
	if ( ! is_array( $orders ) ) {
		return 0.0;
	}
	foreach ( $orders as $order ) {
		if ( ! is_array( $order ) ) {
			continue;
		}
		$status = strtolower( trim( (string) ( $order['status'] ?? '' ) ) );
		if ( '' === $status || false !== strpos( $status, 'out for' ) || false !== strpos( $status, 'undeliver' ) ) {
			continue;
		}
		if ( ! preg_match( '/\bdelivered\b/', $status ) ) {
			continue;
		}
		$amount = $order['totalAmount'] ?? ( $order['total'] ?? 0 );
		$total += (float) $amount;
	}
	return $total;
}

/**
 * Code 39 bars for the loyalty card number.
 *
 * @param string $text Card number.
 * @return string HTML
 */
function amz_prints_barcode_markup( $text ) {
	$patterns = array(
		'0' => 'nnnwwnwnn', '1' => 'wnnwnnnnw', '2' => 'nnwwnnnnw', '3' => 'wnwwnnnnn',
		'4' => 'nnnwwnnnw', '5' => 'wnnwwnnnn', '6' => 'nnwwwnnnn', '7' => 'nnnwnnwnw',
		'8' => 'wnnwnnwnn', '9' => 'nnwwnnwnn', 'A' => 'wnnnnwnnw', 'B' => 'nnwnnwnnw',
		'C' => 'wnwnnwnnn', 'D' => 'nnnnwwnnw', 'E' => 'wnnnwwnnn', 'F' => 'nnwnwwnnn',
		'G' => 'nnnnnwwnw', 'H' => 'wnnnnwwnn', 'I' => 'nnwnnwwnn', 'J' => 'nnnnwwwnn',
		'K' => 'wnnnnnnww', 'L' => 'nnwnnnnww', 'M' => 'wnwnnnnwn', 'N' => 'nnnnwnnww',
		'O' => 'wnnnwnnwn', 'P' => 'nnwnwnnwn', 'Q' => 'nnnnnnwww', 'R' => 'wnnnnnwwn',
		'S' => 'nnwnnnwwn', 'T' => 'nnnnwnwwn', 'U' => 'wwnnnnnnw', 'V' => 'nwwnnnnnw',
		'W' => 'wwwnnnnnn', 'X' => 'nwnnwnnnw', 'Y' => 'wwnnwnnnn', 'Z' => 'nwwnwnnnn',
		'-' => 'nwnnnnwnw', '.' => 'wwnnnnwnn', ' ' => 'nwwnnnwnn', '*' => 'nwnnwnwnn',
	);
	$text = strtoupper( preg_replace( '/[^0-9A-Z\-.]/', '', (string) $text ) );
	if ( '' === $text ) {
		$text = 'AMZ';
	}
	$encoded = '*' . $text . '*';
	$html    = '<div class="loyalty-barcode" aria-hidden="true">';
	$length  = strlen( $encoded );
	for ( $i = 0; $i < $length; $i++ ) {
		$char = $encoded[ $i ];
		if ( ! isset( $patterns[ $char ] ) ) {
			continue;
		}
		$seq   = $patterns[ $char ];
		$isbar = true;
		$seq_n = strlen( $seq );
		for ( $k = 0; $k < $seq_n; $k++ ) {
			$wide = ( 'w' === $seq[ $k ] );
			$w    = $wide ? 4 : 2;
			$html .= $isbar
				? '<i style="width:' . $w . 'px"></i>'
				: '<b style="width:' . $w . 'px"></b>';
			$isbar = ! $isbar;
		}
		$html .= '<b style="width:2px"></b>';
	}
	$html .= '</div>';
	return $html;
}

/**
 * Store a customer profile photo in the uploads folder.
 *
 * @return string|WP_Error URL, empty string when no file, or error.
 */
function amz_prints_customer_store_photo() {
	if ( empty( $_FILES['photo']['name'] ) ) {
		return '';
	}
	$file = $_FILES['photo'];
	if ( UPLOAD_ERR_NO_FILE === (int) ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) ) {
		return '';
	}
	if ( ! empty( $file['error'] ) ) {
		return new WP_Error( 'amz_photo', __( 'Could not upload the profile picture. Use a JPG or PNG under 2 MB.', 'amz-prints' ) );
	}
	if ( (int) ( $file['size'] ?? 0 ) > 2 * 1024 * 1024 ) {
		return new WP_Error( 'amz_photo', __( 'Profile picture must be under 2 MB.', 'amz-prints' ) );
	}
	$check   = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'] );
	$allowed = array( 'jpg', 'jpeg', 'png', 'webp' );
	if ( empty( $check['ext'] ) || ! in_array( strtolower( (string) $check['ext'] ), $allowed, true ) ) {
		return new WP_Error( 'amz_photo', __( 'Use a JPG, PNG, or WebP picture.', 'amz-prints' ) );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	$upload = wp_handle_upload(
		$file,
		array(
			'test_form' => false,
			'mimes'     => array(
				'jpg|jpeg|jpe' => 'image/jpeg',
				'png'          => 'image/png',
				'webp'         => 'image/webp',
			),
		)
	);
	if ( ! empty( $upload['error'] ) ) {
		return new WP_Error( 'amz_photo', __( 'Could not upload the profile picture. Try a smaller JPG or PNG.', 'amz-prints' ) );
	}
	return (string) ( $upload['url'] ?? '' );
}

/**
 * AJAX: save this customer's full profile. Works for website customers, not only WP admins.
 */
function amz_prints_ajax_customer_profile() {
	check_ajax_referer( 'amz_prints_customer', 'nonce' );
	$token = amz_prints_customer_token();
	$local = $token ? amz_prints_local_session_customer( $token ) : null;
	if ( ! is_array( $local ) || empty( $local['customer']['email'] ) ) {
		wp_send_json_error( array( 'message' => __( 'Please log in again, then save your profile.', 'amz-prints' ) ), 401 );
	}
	$email    = strtolower( trim( (string) $local['customer']['email'] ) );
	$name     = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$phone    = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
	$street   = isset( $_POST['street'] ) ? sanitize_text_field( wp_unslash( $_POST['street'] ) ) : '';
	$area     = isset( $_POST['area'] ) ? sanitize_text_field( wp_unslash( $_POST['area'] ) ) : '';
	$city     = isset( $_POST['city'] ) ? sanitize_text_field( wp_unslash( $_POST['city'] ) ) : '';
	$postal   = isset( $_POST['postal'] ) ? sanitize_text_field( wp_unslash( $_POST['postal'] ) ) : '';
	$landmark = isset( $_POST['landmark'] ) ? sanitize_text_field( wp_unslash( $_POST['landmark'] ) ) : '';
	if ( strlen( $street ) < 3 || strlen( $area ) < 2 || strlen( $city ) < 2 ) {
		wp_send_json_error( array( 'message' => __( 'Enter your street, area, and city so the delivery address is complete.', 'amz-prints' ) ), 400 );
	}
	$address  = implode( ', ', array_filter( array( $street, $area, $city, $postal, $landmark ) ) );
	$identity = amz_prints_customer_validate_identity( $name, $email, $phone, $address, true );
	if ( is_wp_error( $identity ) ) {
		wp_send_json_error( array( 'message' => $identity->get_error_message() ), 400 );
	}
	$photo = amz_prints_customer_store_photo();
	if ( is_wp_error( $photo ) ) {
		wp_send_json_error( array( 'message' => $photo->get_error_message() ), 400 );
	}
	$row = amz_prints_local_customer_get( $email );
	$row = is_array( $row ) ? $row : array();
	$row['name']     = $identity['name'];
	$row['email']    = $email;
	$row['phone']    = $identity['phone'];
	$row['street']   = $street;
	$row['area']     = $area;
	$row['city']     = $city;
	$row['postal']   = $postal;
	$row['landmark'] = $landmark;
	$row['address']  = $address;
	$row['verified'] = true;
	if ( $photo ) {
		$row['photo'] = $photo;
	}
	amz_prints_local_customer_save( $email, $row );
	amz_prints_remember_portal_session( $token, amz_prints_customer_card_fields( $row ) );
	wp_send_json_success( array(
		'message'  => __( 'Profile saved for this account.', 'amz-prints' ),
		'customer' => amz_prints_customer_card_fields( $row ),
	) );
}
add_action( 'wp_ajax_amz_prints_customer_profile', 'amz_prints_ajax_customer_profile' );
add_action( 'wp_ajax_nopriv_amz_prints_customer_profile', 'amz_prints_ajax_customer_profile' );
add_action( 'wp_ajax_amz_prints_customer_track', 'amz_prints_ajax_customer_track' );
add_action( 'wp_ajax_nopriv_amz_prints_customer_track', 'amz_prints_ajax_customer_track' );

/**
 * Stored CVs, keyed by customer email.
 *
 * @return array<string,array<string,mixed>>
 */
function amz_prints_customer_cvs() {
	$all = get_option( 'amz_prints_customer_cvs', array() );
	return is_array( $all ) ? $all : array();
}

/**
 * @param string $email Customer email.
 * @return array<string,mixed>|null
 */
function amz_prints_customer_cv_get( $email ) {
	$email = strtolower( trim( (string) $email ) );
	$all   = amz_prints_customer_cvs();
	return ( $email && isset( $all[ $email ] ) && is_array( $all[ $email ] ) ) ? $all[ $email ] : null;
}

/**
 * @param string $token Public view token.
 * @return array<string,mixed>|null
 */
function amz_prints_customer_cv_by_token( $token ) {
	$token = (string) $token;
	if ( strlen( $token ) < 16 ) {
		return null;
	}
	foreach ( amz_prints_customer_cvs() as $row ) {
		if ( is_array( $row ) && ! empty( $row['token'] ) && hash_equals( (string) $row['token'], $token ) ) {
			return $row;
		}
	}
	return null;
}

/**
 * Uploads folder used for CV photos.
 *
 * @return array|WP_Error { dir, baseurl }
 */
function amz_prints_customer_cv_photo_dir() {
	$upload = wp_upload_dir();
	if ( ! empty( $upload['error'] ) ) {
		return new WP_Error( 'amz_cv_photo', __( 'Could not store the CV photo.', 'amz-prints' ) );
	}
	$dir = trailingslashit( $upload['basedir'] ) . 'amz-cv';
	if ( ! wp_mkdir_p( $dir ) ) {
		return new WP_Error( 'amz_cv_photo', __( 'Could not store the CV photo.', 'amz-prints' ) );
	}
	$index = $dir . '/index.php';
	if ( ! file_exists( $index ) ) {
		file_put_contents( $index, "<?php\n// Silence is golden.\n" );
	}
	return array(
		'dir'     => $dir,
		'baseurl' => $upload['baseurl'],
	);
}

/**
 * Public URL for this customer's CV photo file.
 *
 * @param string              $email Customer email.
 * @param string              $ext   jpg, png, or webp.
 * @param array<string,mixed> $dir   Result of amz_prints_customer_cv_photo_dir().
 * @return array{path:string,url:string}
 */
function amz_prints_customer_cv_photo_target( $email, $ext, $dir ) {
	$hash = md5( strtolower( $email ) );
	$name = 'cv-' . $hash . '.' . $ext;
	foreach ( array( 'jpg', 'png', 'webp' ) as $old_ext ) {
		$old = $dir['dir'] . '/cv-' . $hash . '.' . $old_ext;
		if ( $old_ext !== $ext && file_exists( $old ) ) {
			unlink( $old );
		}
	}
	return array(
		'path' => $dir['dir'] . '/' . $name,
		'url'  => trailingslashit( $dir['baseurl'] ) . 'amz-cv/' . $name . '?v=' . time(),
	);
}

/**
 * Store the photo sent as a real file upload.
 *
 * @param string $email Customer email.
 * @return string|WP_Error Public URL, empty string when no file, or error.
 */
function amz_prints_customer_cv_store_uploaded_file( $email ) {
	if ( empty( $_FILES['photo']['tmp_name'] ) ) {
		return '';
	}
	$file = $_FILES['photo'];
	if ( ! empty( $file['error'] ) ) {
		return new WP_Error( 'amz_cv_photo', __( 'Could not upload the CV photo. Use a JPG or PNG under 2 MB.', 'amz-prints' ) );
	}
	if ( ! is_uploaded_file( $file['tmp_name'] ) ) {
		return new WP_Error( 'amz_cv_photo', __( 'Could not upload the CV photo.', 'amz-prints' ) );
	}
	if ( (int) $file['size'] > 2 * 1024 * 1024 ) {
		return new WP_Error( 'amz_cv_photo', __( 'That photo is too large. Use a JPG or PNG under 2 MB.', 'amz-prints' ) );
	}
	$info = @getimagesize( $file['tmp_name'] );
	$map  = array(
		'image/jpeg' => 'jpg',
		'image/png'  => 'png',
		'image/webp' => 'webp',
	);
	$mime = is_array( $info ) ? (string) ( $info['mime'] ?? '' ) : '';
	if ( ! isset( $map[ $mime ] ) ) {
		return new WP_Error( 'amz_cv_photo', __( 'Upload a JPG, PNG, or WebP photo for the CV.', 'amz-prints' ) );
	}
	$dir = amz_prints_customer_cv_photo_dir();
	if ( is_wp_error( $dir ) ) {
		return $dir;
	}
	$target = amz_prints_customer_cv_photo_target( $email, $map[ $mime ], $dir );
	if ( ! move_uploaded_file( $file['tmp_name'], $target['path'] ) ) {
		return new WP_Error( 'amz_cv_photo', __( 'Could not store the CV photo.', 'amz-prints' ) );
	}
	return $target['url'];
}

/**
 * Write a CV photo from a data URL into uploads/amz-cv.
 *
 * @param string $email    Customer email.
 * @param string $data_url data:image or https URL.
 * @return string|WP_Error Public URL or error.
 */
function amz_prints_customer_cv_store_photo( $email, $data_url ) {
	$data_url = (string) $data_url;
	if ( preg_match( '#^https?://#i', $data_url ) ) {
		return esc_url_raw( $data_url );
	}
	if ( preg_match( '#^(blob:|data:application/)#i', $data_url ) ) {
		return new WP_Error( 'amz_cv_photo', __( 'Upload a JPG, PNG, or WebP photo for the CV.', 'amz-prints' ) );
	}
	if ( ! preg_match( '#^data:image/(jpeg|jpg|png|webp);base64,#i', $data_url, $match ) ) {
		return new WP_Error( 'amz_cv_photo', __( 'Upload a JPG, PNG, or WebP photo for the CV.', 'amz-prints' ) );
	}
	$comma = strpos( $data_url, ',' );
	$raw   = ( false === $comma ) ? '' : base64_decode( substr( $data_url, $comma + 1 ), true );
	if ( ! is_string( $raw ) || '' === $raw || strlen( $raw ) > 2 * 1024 * 1024 ) {
		return new WP_Error( 'amz_cv_photo', __( 'That photo is too large. Use a JPG or PNG under 2 MB.', 'amz-prints' ) );
	}
	$ext = strtolower( $match[1] );
	if ( 'jpeg' === $ext ) {
		$ext = 'jpg';
	}
	$dir = amz_prints_customer_cv_photo_dir();
	if ( is_wp_error( $dir ) ) {
		return $dir;
	}
	$target = amz_prints_customer_cv_photo_target( $email, $ext, $dir );
	if ( false === file_put_contents( $target['path'], $raw ) ) {
		return new WP_Error( 'amz_cv_photo', __( 'Could not store the CV photo.', 'amz-prints' ) );
	}
	return $target['url'];
}

/**
 * Keep only the CV builder fields we store.
 *
 * @param mixed $state Raw decoded state.
 * @return array<string,mixed>
 */
function amz_prints_customer_cv_clean_state( $state ) {
	if ( ! is_array( $state ) ) {
		return array();
	}
	$keep = array(
		'template', 'color', 'photo', 'enabled', 'personal', 'summary', 'hobbies', 'contact',
		'experience', 'internships', 'volunteer', 'education', 'skills', 'professionalSkills',
		'technicalSkills', 'certifications', 'courses', 'awards', 'publications', 'projects',
		'languages', 'references', 'links', 'custom',
	);
	$out = array();
	foreach ( $keep as $key ) {
		if ( array_key_exists( $key, $state ) ) {
			$out[ $key ] = $state[ $key ];
		}
	}
	return $out;
}

/**
 * @param string $html CV page HTML.
 * @return string
 */
function amz_prints_customer_cv_kses( $html ) {
	$allowed = array(
		'article' => array( 'class' => true, 'style' => true ),
		'div'     => array( 'class' => true, 'style' => true ),
		'span'    => array( 'class' => true ),
		'img'     => array( 'class' => true, 'alt' => true, 'src' => true ),
		'ul'      => array( 'class' => true, 'style' => true ),
		'ol'      => array( 'class' => true, 'style' => true ),
		'li'      => array( 'style' => true ),
		'strong'  => array(),
		'b'       => array(),
		'em'      => array(),
		'i'       => array(),
		'u'       => array(),
		'p'       => array( 'class' => true, 'style' => true ),
		'h1'      => array( 'class' => true ),
		'h2'      => array(),
		'h3'      => array(),
		'section' => array( 'class' => true ),
		'br'      => array(),
	);
	$html = wp_kses( (string) $html, $allowed );
	$html = preg_replace_callback(
		'/ style="([^"]*)"/',
		static function ( $m ) {
			$style = trim( (string) $m[1] );
			if ( preg_match( '/^--cv-accent:\s*#[0-9a-fA-F]{3,8};?$/', $style ) ) {
				return ' style="' . esc_attr( $style ) . '"';
			}
			$keep = array();
			if ( preg_match( '/text-align\s*:\s*(left|center|right|justify)/i', $style, $align ) ) {
				$keep[] = 'text-align:' . strtolower( $align[1] );
			}
			if ( preg_match( '/margin-left\s*:\s*(\d+(?:\.\d+)?)(px|em)/i', $style, $indent ) ) {
				$px = (float) $indent[1];
				if ( 'em' === strtolower( $indent[2] ) ) {
					$px *= 16;
				}
				$px = (int) ( round( $px / 24 ) * 24 );
				$px = max( 0, min( 160, $px ) );
				if ( $px > 0 ) {
					$keep[] = 'margin-left:' . $px . 'px';
				}
			}
			if ( preg_match( '/list-style-type\s*:\s*(disc|circle|square|decimal|lower-alpha|upper-alpha|lower-roman|upper-roman)/i', $style, $list ) ) {
				$keep[] = 'list-style-type:' . strtolower( $list[1] );
			}
			if ( ! $keep ) {
				return '';
			}
			return ' style="' . esc_attr( implode( ';', $keep ) ) . '"';
		},
		$html
	);
	return is_string( $html ) ? $html : '';
}

/**
 * Push the public CV link into the ERP customer notes as Customer's CV.
 *
 * @param string $email    Customer email.
 * @param string $cv_url   Public CV URL.
 * @param string $photo_url Photo URL.
 */
function amz_prints_customer_cv_push_erp( $email, $cv_url, $photo_url ) {
	if ( ! function_exists( 'amz_prints_customer_api' ) || ! $cv_url ) {
		return;
	}
	$row = amz_prints_local_customer_get( $email );
	$row = is_array( $row ) ? $row : array();
	amz_prints_customer_api( '/public/customer/cv', array(
		'portalKey' => amz_prints_customer_portal_key(),
		'email'     => $email,
		'name'      => (string) ( $row['name'] ?? '' ),
		'phone'     => (string) ( $row['phone'] ?? '' ),
		'address'   => (string) ( $row['address'] ?? '' ),
		'cvUrl'     => $cv_url,
		'photoUrl'  => $photo_url,
	) );
}

/**
 * AJAX: save or update the logged-in customer's CV.
 */
function amz_prints_ajax_save_cv() {
	check_ajax_referer( 'amz_prints_customer', 'nonce' );
	$email = amz_prints_customer_current_email();
	if ( ! $email ) {
		wp_send_json_error( array( 'message' => __( 'Log in to save your CV.', 'amz-prints' ) ), 401 );
	}
	$clear = isset( $_POST['clear'] ) && '1' === (string) wp_unslash( $_POST['clear'] );
	$raw   = isset( $_POST['state'] ) ? wp_unslash( $_POST['state'] ) : '';
	$state = json_decode( is_string( $raw ) ? $raw : '', true );
	$state = amz_prints_customer_cv_clean_state( $state );
	$html  = isset( $_POST['html'] ) ? wp_unslash( $_POST['html'] ) : '';
	$html  = is_string( $html ) ? $html : '';
	if ( strlen( $html ) > 400000 ) {
		$html = '';
	}

	$existing = amz_prints_customer_cv_get( $email );
	$token    = ( is_array( $existing ) && ! empty( $existing['token'] ) ) ? (string) $existing['token'] : bin2hex( random_bytes( 16 ) );
	$photo    = '';
	if ( ! $clear ) {
		$uploaded = amz_prints_customer_cv_store_uploaded_file( $email );
		if ( is_wp_error( $uploaded ) ) {
			wp_send_json_error( array( 'message' => $uploaded->get_error_message() ), 400 );
		}
		$incoming = (string) ( $state['photo'] ?? '' );
		if ( preg_match( '#^(blob:|data:)#i', $incoming ) ) {
			$incoming = '';
		}
		if ( '' === $incoming && is_array( $existing ) ) {
			$incoming = (string) ( $existing['photo'] ?? '' );
		}
		$remove_photo = isset( $_POST['remove_photo'] ) && '1' === (string) wp_unslash( $_POST['remove_photo'] );
		if ( $uploaded ) {
			$photo = $uploaded;
		} elseif ( $remove_photo ) {
			$photo = '';
		} elseif ( '' === $incoming ) {
			$photo = '';
		} else {
			$stored = amz_prints_customer_cv_store_photo( $email, $incoming );
			if ( is_wp_error( $stored ) ) {
				wp_send_json_error( array( 'message' => $stored->get_error_message() ), 400 );
			}
			$photo = $stored;
		}
		$state['photo'] = $photo;
		if ( $html && $photo ) {
			$src  = esc_url( $photo );
			$html = preg_replace_callback(
				'#<img\b[^>]*class="cv-photo"[^>]*>#i',
				static function ( $match ) use ( $src ) {
					$tag = $match[0];
					if ( preg_match( '#\ssrc="#', $tag ) ) {
						return preg_replace( '#\ssrc="[^"]*"#', ' src="' . $src . '"', $tag, 1 );
					}
					return preg_replace( '#^<img\b#i', '<img src="' . $src . '"', $tag, 1 );
				},
				$html
			);
		}
		$html = amz_prints_customer_cv_kses( $html );
	} else {
		$state['photo'] = '';
		$html           = '';
	}

	$all            = amz_prints_customer_cvs();
	$all[ $email ]  = array(
		'token'   => $token,
		'email'   => $email,
		'state'   => $state,
		'html'    => $html,
		'photo'   => $photo,
		'updated' => time(),
	);
	update_option( 'amz_prints_customer_cvs', $all, false );

	$cv_url = add_query_arg( 'amz_cv', rawurlencode( $token ), home_url( '/' ) );
	if ( ! $clear ) {
		amz_prints_customer_ensure_erp( $email );
		amz_prints_customer_cv_push_erp( $email, $cv_url, $photo );
	}
	wp_send_json_success( array(
		'message'  => $clear ? __( 'CV cleared on this account.', 'amz-prints' ) : __( 'CV saved on your account.', 'amz-prints' ),
		'photoUrl' => $photo,
		'cvUrl'    => $cv_url,
	) );
}
add_action( 'wp_ajax_amz_prints_save_cv', 'amz_prints_ajax_save_cv' );
add_action( 'wp_ajax_nopriv_amz_prints_save_cv', 'amz_prints_ajax_save_cv' );

/**
 * Staff and the customer open a saved CV from the ERP link.
 */
function amz_prints_customer_cv_public_view() {
	if ( empty( $_GET['amz_cv'] ) ) {
		return;
	}
	$token = sanitize_text_field( wp_unslash( $_GET['amz_cv'] ) );
	$row   = amz_prints_customer_cv_by_token( $token );
	status_header( $row ? 200 : 404 );
	header( 'Content-Type: text/html; charset=UTF-8' );
	header( 'Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0' );
	header( 'X-Robots-Tag: noindex, nofollow' );
	$css  = get_template_directory_uri() . '/assets/css/cv-builder.css?ver=' . rawurlencode( AMZ_PRINTS_VERSION );
	$html = ( $row && ! empty( $row['html'] ) ) ? (string) $row['html'] : '<p class="cv-muted">This CV is not available.</p>';
	$photo_url = '';
	if ( is_array( $row ) ) {
		$photo_url = (string) ( $row['photo'] ?? '' );
		if ( ! $photo_url && ! empty( $row['state']['photo'] ) ) {
			$photo_url = (string) $row['state']['photo'];
		}
	}
	if ( $photo_url && preg_match( '#^https?://#i', $photo_url ) && preg_match( '#<img\b[^>]*class="cv-photo"#i', $html ) ) {
		$src  = esc_url( $photo_url );
		$html = preg_replace_callback(
			'#<img\b[^>]*class="cv-photo"[^>]*>#i',
			static function ( $match ) use ( $src ) {
				$tag = $match[0];
				if ( preg_match( '#\ssrc="https?://#i', $tag ) ) {
					return $tag;
				}
				if ( preg_match( '#\ssrc="#', $tag ) ) {
					return preg_replace( '#\ssrc="[^"]*"#', ' src="' . $src . '"', $tag, 1 );
				}
				return preg_replace( '#^<img\b#i', '<img src="' . $src . '"', $tag, 1 );
			},
			$html
		);
	}
	echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
	echo '<title>' . esc_html__( "Customer's CV", 'amz-prints' ) . '</title>';
	echo '<link rel="stylesheet" href="' . esc_url( $css ) . '">';
	echo '<style>body{margin:0;background:#eef2f6}.cv-public{display:grid;gap:16px;justify-items:center;padding:16px}@media print{body{background:#fff}.cv-public{padding:0;gap:0}}</style>';
	echo '</head><body class="amz-cv-builder"><div class="cv-public">';
	echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- kses on save.
	echo '</div></body></html>';
	exit;
}
add_action( 'template_redirect', 'amz_prints_customer_cv_public_view', 2 );
