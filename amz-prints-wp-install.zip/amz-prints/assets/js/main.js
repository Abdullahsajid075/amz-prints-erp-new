/**
 * AMZ Prints — mega menu (click stay open), WhatsApp forms, hero, AI
 */
(function () {
  'use strict';

  var cfg = window.amzPrints || {};
  var header = document.getElementById('site-header');
  var toggle = document.getElementById('nav-toggle');
  var nav = document.getElementById('site-nav');

  function onScroll() {
    if (!header) return;
    header.classList.toggle('is-scrolled', window.scrollY > 24);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  function setNav(open) {
    if (!toggle || !nav) return;
    nav.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    document.body.classList.toggle('nav-open', open);
  }

  if (toggle && nav) {
    toggle.addEventListener('click', function (e) {
      e.stopPropagation();
      setNav(!nav.classList.contains('is-open'));
    });
    nav.addEventListener('click', function (e) {
      if (e.target === nav || (e.target.closest && e.target.closest('a'))) {
        setNav(false);
      }
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') setNav(false);
    });
  }

  /* More dropdown */
  var moreTrigger = document.querySelector('.more-trigger');
  var moreMenu = document.getElementById('more-menu');
  if (moreTrigger && moreMenu) {
    moreTrigger.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var open = !moreMenu.classList.contains('is-open');
      closeMega();
      moreMenu.classList.toggle('is-open', open);
      moreTrigger.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  /* Mega menu — click to open, stays open until outside click */
  var mega = document.getElementById('mega-menu-services');
  var megaTrigger = document.querySelector('.mega-trigger');

  function openMega() {
    if (!mega || !megaTrigger) return;
    if (moreMenu) {
      moreMenu.classList.remove('is-open');
      if (moreTrigger) moreTrigger.setAttribute('aria-expanded', 'false');
    }
    mega.classList.add('is-open');
    header && header.classList.add('mega-open');
    megaTrigger.setAttribute('aria-expanded', 'true');
  }
  function closeMega() {
    if (!mega || !megaTrigger) return;
    mega.classList.remove('is-open');
    header && header.classList.remove('mega-open');
    megaTrigger.setAttribute('aria-expanded', 'false');
  }

  if (mega && megaTrigger) {
    megaTrigger.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      if (mega.classList.contains('is-open')) closeMega();
      else openMega();
    });
    mega.addEventListener('click', function (e) {
      e.stopPropagation();
    });
  }

  document.addEventListener('click', function () {
    closeMega();
    if (moreMenu) {
      moreMenu.classList.remove('is-open');
      if (moreTrigger) moreTrigger.setAttribute('aria-expanded', 'false');
    }
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      closeMega();
      if (moreMenu) moreMenu.classList.remove('is-open');
    }
  });

  /* Reveal */
  var reveals = document.querySelectorAll('[data-reveal]');
  if ('IntersectionObserver' in window && reveals.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    reveals.forEach(function (el, i) {
      el.style.setProperty('--reveal-delay', (i % 6) * 60 + 'ms');
      io.observe(el);
    });
  } else {
    reveals.forEach(function (el) { el.classList.add('is-visible'); });
  }

  /* Shop category filter + carousel */
  (function initShop() {
    var cats = document.querySelector('[data-shop-cats]');
    var track = document.querySelector('[data-shop-track]');
    var grid = document.querySelector('[data-shop-grid]');
    var cardsRoot = track || grid;
    if (!cardsRoot) return;

    function visibleCards() {
      return Array.prototype.slice.call(cardsRoot.querySelectorAll('.shop-card')).filter(function (c) {
        return c.style.display !== 'none';
      });
    }

    var limit = grid ? parseInt(grid.getAttribute('data-shop-limit'), 10) || 0 : 0;
    var step = grid ? parseInt(grid.getAttribute('data-shop-step'), 10) || 8 : 8;
    var shown = limit;
    var moreBtn = document.querySelector('[data-shop-more]');
    function applyLimit() {
      if (!limit) return;
      var cards = visibleCards();
      cards.forEach(function (card, i) { card.classList.toggle('is-over-limit', i >= shown); });
      if (moreBtn && moreBtn.parentNode) moreBtn.parentNode.hidden = cards.length <= shown;
    }
    if (moreBtn) {
      moreBtn.addEventListener('click', function () {
        shown += step;
        applyLimit();
      });
    }
    applyLimit();

    if (cats) {
      cats.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-cat]');
        if (!btn) return;
        var cat = btn.getAttribute('data-cat');
        cats.querySelectorAll('[data-cat]').forEach(function (b) {
          b.classList.toggle('is-active', b === btn);
        });
        cardsRoot.querySelectorAll('.shop-card').forEach(function (card) {
          var match = cat === 'all' || card.getAttribute('data-category') === cat;
          card.style.display = match ? '' : 'none';
        });
        shown = limit;
        applyLimit();
        if (track) goTo(0);
        buildDots();
      });
    }

    if (!track) return;
    var page = 0;
    var dotsWrap = document.querySelector('[data-shop-dots]');
    var prev = document.querySelector('[data-shop-prev]');
    var next = document.querySelector('[data-shop-next]');

    function perPage() {
      if (window.innerWidth <= 560) return 1;
      if (window.innerWidth <= 900) return 2;
      return 3;
    }

    function maxPage() {
      var n = visibleCards().length;
      return Math.max(0, Math.ceil(n / perPage()) - 1);
    }

    function goTo(p) {
      page = Math.max(0, Math.min(p, maxPage()));
      var card = visibleCards()[0];
      var gap = 18;
      var w = card ? card.getBoundingClientRect().width + gap : 280;
      track.style.transform = 'translateX(' + (-page * perPage() * w) + 'px)';
      if (dotsWrap) {
        Array.prototype.forEach.call(dotsWrap.children, function (d, i) {
          d.classList.toggle('is-active', i === page);
        });
      }
    }

    function buildDots() {
      if (!dotsWrap) return;
      dotsWrap.innerHTML = '';
      var m = maxPage();
      for (var i = 0; i <= m; i++) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'shop-dot' + (i === page ? ' is-active' : '');
        b.setAttribute('data-shop-dot', String(i));
        dotsWrap.appendChild(b);
      }
      goTo(Math.min(page, m));
    }

    if (prev) prev.addEventListener('click', function () { goTo(page - 1); });
    if (next) next.addEventListener('click', function () { goTo(page + 1); });
    if (dotsWrap) {
      dotsWrap.addEventListener('click', function (e) {
        var d = e.target.closest('[data-shop-dot]');
        if (!d) return;
        goTo(parseInt(d.getAttribute('data-shop-dot'), 10) || 0);
      });
    }
    window.addEventListener('resize', function () { buildDots(); });
    buildDots();
  })();

  /* Homepage banner — one photo first, a short fade, no floating animation */
  var stageRoot = document.querySelector('[data-hero-rotator]');
  if (stageRoot) {
    var stageSlides = Array.prototype.slice.call(stageRoot.querySelectorAll('[data-slide]'));
    var stageDots = Array.prototype.slice.call(stageRoot.querySelectorAll('[data-stage-dot]'));
    var stageWait = parseInt(stageRoot.getAttribute('data-interval'), 10) || 7000;
    var stageIndex = 0;
    var stageTimer = null;
    var stageEditing = /(?:\?|&)amz-edit=1(?:&|$)/.test(window.location.search);
    function stageSrc(slide) {
      if (!slide) return;
      Array.prototype.forEach.call(slide.querySelectorAll('[data-srcset]'), function (node) {
        node.setAttribute('srcset', node.getAttribute('data-srcset'));
        node.removeAttribute('data-srcset');
      });
      var img = slide.querySelector('img[data-src]');
      if (!img) return;
      img.src = img.getAttribute('data-src');
      img.removeAttribute('data-src');
    }
    function stageShow(next) {
      if (stageSlides.length < 2) return;
      var target = (next + stageSlides.length) % stageSlides.length;
      if (target === stageIndex) return;
      stageSrc(stageSlides[target]);
      stageSlides[stageIndex].classList.remove('is-active');
      stageSlides[target].classList.add('is-active');
      stageDots.forEach(function (dot, i) { dot.classList.toggle('is-active', i === target); });
      stageIndex = target;
    }
    function stageStart() {
      if (stageTimer) window.clearInterval(stageTimer);
      if (stageSlides.length > 1 && !stageEditing) {
        stageTimer = window.setInterval(function () { stageShow(stageIndex + 1); }, stageWait);
      }
    }
    if (stageEditing) {
      stageSlides.forEach(stageSrc);
    } else {
      var firstImg = stageSlides[0] && stageSlides[0].querySelector('img');
      var prefetchNext = function () { stageSrc(stageSlides[1]); };
      if (firstImg && !firstImg.complete) firstImg.addEventListener('load', prefetchNext, { once: true });
      else window.setTimeout(prefetchNext, 800);
    }
    stageDots.forEach(function (dot) {
      dot.addEventListener('click', function () {
        var t = parseInt(dot.getAttribute('data-stage-dot'), 10);
        if (!isNaN(t)) { stageShow(t); stageStart(); }
      });
    });
    stageStart();
  }

  /* Homepage image sliders. The active dot's progress animation drives autoplay,
     so pausing the animation (hover, off-screen, hidden tab) also pauses the slider. */
  Array.prototype.forEach.call(document.querySelectorAll('[data-amz-slider]'), function (root) {
    var slides = Array.prototype.slice.call(root.querySelectorAll('[data-slider-slide]'));
    var dots = Array.prototype.slice.call(root.querySelectorAll('[data-slider-dot]'));
    var track = root.querySelector('[data-slider-track]');
    var isSlide = root.classList.contains('amz-slider--fx-slide');
    var editing = /(?:\?|&)amz-edit=1(?:&|$)/.test(window.location.search);
    var index = 0;
    var hover = false;
    var offscreen = false;
    var loaded = false;

    function loadAll() {
      if (loaded) return;
      loaded = true;
      slides.forEach(function (slide) {
        Array.prototype.forEach.call(slide.querySelectorAll('[data-srcset]'), function (node) {
          node.setAttribute('srcset', node.getAttribute('data-srcset'));
          node.removeAttribute('data-srcset');
        });
        Array.prototype.forEach.call(slide.querySelectorAll('img[data-src]'), function (img) {
          img.src = img.getAttribute('data-src');
          img.removeAttribute('data-src');
        });
      });
    }

    function syncPause() {
      root.classList.toggle('is-paused', editing || hover || offscreen || document.hidden);
    }

    function go(next) {
      if (slides.length < 2) return;
      loadAll();
      root.classList.add('has-moved');
      var target = (next + slides.length) % slides.length;
      slides[index].classList.remove('is-active');
      slides[target].classList.add('is-active');
      dots.forEach(function (dot, i) { dot.classList.toggle('is-active', i === target); });
      if (isSlide && track) track.style.transform = 'translateX(' + (-100 * target) + '%)';
      index = target;
      fitHeight();
    }

    var viewport = root.querySelector('.amz-slider__viewport') || root;
    function fitHeight() {
      if (!isSlide || slides.length < 2) return;
      var h = slides[index].offsetHeight;
      if (h) viewport.style.height = h + 'px';
    }
    if (isSlide) {
      Array.prototype.forEach.call(root.querySelectorAll('img'), function (img) {
        img.addEventListener('load', fitHeight);
      });
      window.addEventListener('resize', fitHeight);
      fitHeight();
    }

    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          offscreen = !entry.isIntersecting;
          if (entry.isIntersecting) loadAll();
          syncPause();
        });
      }, { rootMargin: '300px 0px' }).observe(root);
    } else {
      loadAll();
    }

    if (slides.length < 2) return;

    var dotsWrap = root.querySelector('.amz-slider__dots');
    if (dotsWrap) {
      dotsWrap.addEventListener('animationend', function (e) {
        if (e.animationName === 'amzSliderProgress') go(index + 1);
      });
    }
    dots.forEach(function (dot) {
      dot.addEventListener('click', function () {
        var t = parseInt(dot.getAttribute('data-slider-dot'), 10);
        if (!isNaN(t) && t !== index) go(t);
      });
    });
    var prev = root.querySelector('[data-slider-prev]');
    var next = root.querySelector('[data-slider-next]');
    if (prev) prev.addEventListener('click', function () { go(index - 1); });
    if (next) next.addEventListener('click', function () { go(index + 1); });

    var frame = root.querySelector('.amz-slider__frame') || root;
    frame.addEventListener('mouseenter', function () { hover = true; syncPause(); });
    frame.addEventListener('mouseleave', function () { hover = false; syncPause(); });
    frame.addEventListener('focusin', function () { hover = true; syncPause(); });
    frame.addEventListener('focusout', function () { hover = false; syncPause(); });
    document.addEventListener('visibilitychange', syncPause);

    var startX = null;
    var swiped = false;
    viewport.addEventListener('pointerdown', function (e) { startX = e.clientX; swiped = false; });
    viewport.addEventListener('pointerup', function (e) {
      if (startX === null) return;
      var dx = e.clientX - startX;
      startX = null;
      if (Math.abs(dx) > 45) {
        swiped = true;
        go(dx < 0 ? index + 1 : index - 1);
      }
    });
    viewport.addEventListener('click', function (e) {
      if (swiped) { e.preventDefault(); swiped = false; }
    }, true);
    viewport.addEventListener('dragstart', function (e) { e.preventDefault(); });
    root.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowLeft') go(index - 1);
      if (e.key === 'ArrowRight') go(index + 1);
    });
    syncPause();
  });

  /* Homepage banners — 1250×250 crossfade */
  var bannerSlider = document.querySelector('[data-banner-slider]');
  if (bannerSlider) {
    var bSlides = Array.prototype.slice.call(bannerSlider.querySelectorAll('.amz-banners__slide'));
    var bDots = Array.prototype.slice.call(bannerSlider.querySelectorAll('[data-banner-dot]'));
    var bInterval = parseInt(bannerSlider.getAttribute('data-hero-interval'), 10) || 4500;
    var bIndex = 0;
    var bTimer = null;
    function bannerGo(next) {
      if (bSlides.length < 2) return;
      bSlides[bIndex].classList.remove('is-active');
      bIndex = (next + bSlides.length) % bSlides.length;
      bSlides[bIndex].classList.add('is-active');
      bDots.forEach(function (dot, i) { dot.classList.toggle('is-active', i === bIndex); });
    }
    function bannerStart() {
      if (bTimer) window.clearInterval(bTimer);
      if (bSlides.length > 1) bTimer = window.setInterval(function () { bannerGo(bIndex + 1); }, bInterval);
    }
    bDots.forEach(function (dot) {
      dot.addEventListener('click', function () {
        var t = parseInt(dot.getAttribute('data-banner-dot'), 10);
        if (!isNaN(t)) { bannerGo(t); bannerStart(); }
      });
    });
    bannerSlider.addEventListener('mouseenter', function () { if (bTimer) window.clearInterval(bTimer); });
    bannerSlider.addEventListener('mouseleave', bannerStart);
    bannerStart();
  }

  /* Hero slider (legacy) */
  var heroSlider = document.querySelector('[data-hero-slider]');
  if (heroSlider) {
    var slides = Array.prototype.slice.call(heroSlider.querySelectorAll('.hero__slide'));
    var dots = Array.prototype.slice.call(heroSlider.querySelectorAll('[data-hero-dot]'));
    var interval = parseInt(heroSlider.getAttribute('data-hero-interval'), 10) || 3000;
    var index = 0;
    var timer = null;
    function goTo(next) {
      if (slides.length < 2) return;
      slides[index].classList.remove('is-active');
      slides[index].classList.add('is-leaving');
      var prev = index;
      index = (next + slides.length) % slides.length;
      slides[index].classList.add('is-active');
      dots.forEach(function (dot, i) { dot.classList.toggle('is-active', i === index); });
      window.setTimeout(function () { slides[prev].classList.remove('is-leaving'); }, 900);
    }
    function start() {
      stop();
      if (slides.length > 1) timer = window.setInterval(function () { goTo(index + 1); }, interval);
    }
    function stop() {
      if (timer) { window.clearInterval(timer); timer = null; }
    }
    dots.forEach(function (dot) {
      dot.addEventListener('click', function () {
        var t = parseInt(dot.getAttribute('data-hero-dot'), 10);
        if (!isNaN(t) && t !== index) { goTo(t); start(); }
      });
    });
    heroSlider.addEventListener('mouseenter', stop);
    heroSlider.addEventListener('mouseleave', start);
    start();
  }

  /* Premium hero — 3 independent sliders (5s) + light parallax */
  var heroPremium = document.querySelector('[data-hero-premium]');
  if (heroPremium) {
    var flex = heroPremium.querySelector('[data-hero-flex]');
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var slots = Array.prototype.slice.call(heroPremium.querySelectorAll('[data-hero-slot]'));

    slots.forEach(function (slot) {
      var slides = Array.prototype.slice.call(slot.querySelectorAll('[data-hero-slide]'));
      var dots = Array.prototype.slice.call(slot.querySelectorAll('.hero-slot__dot'));
      if (slides.length < 2) return;
      var idx = 0;
      var interval = parseInt(slot.getAttribute('data-interval'), 10) || 5000;
      var startDelay = parseInt(slot.getAttribute('data-delay'), 10) || 0;

      function goTo(next) {
        slides[idx].classList.remove('is-active');
        slides[idx].classList.add('is-leaving');
        var prev = idx;
        idx = (next + slides.length) % slides.length;
        slides[idx].classList.add('is-active');
        dots.forEach(function (dot, i) { dot.classList.toggle('is-active', i === idx); });
        window.setTimeout(function () {
          slides[prev].classList.remove('is-leaving');
        }, 700);
      }

      if (!reduce) {
        window.setTimeout(function () {
          window.setInterval(function () { goTo(idx + 1); }, interval);
        }, startDelay);
      }

      slides.forEach(function (slide) {
        slide.addEventListener('keydown', function (e) {
          if ((e.key === 'Enter' || e.key === ' ') && slide.getAttribute('data-open-product')) {
            e.preventDefault();
            slide.click();
          }
        });
      });
    });

    if (!reduce && flex) {
      heroPremium.addEventListener('pointermove', function (e) {
        var rect = heroPremium.getBoundingClientRect();
        var x = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
        var y = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
        flex.style.transform = 'rotateY(' + (x * -4) + 'deg) rotateX(' + (y * 3) + 'deg) translateZ(0)';
      });
      heroPremium.addEventListener('pointerleave', function () {
        flex.style.transform = '';
      });
    }
  }

  /* Build WhatsApp message from form */
  function buildWaMessage(form) {
    var fd = new FormData(form);
    var lines = [];
    lines.push('Hello, I would like a quote.');
    lines.push('Name: ' + (fd.get('name') || ''));
    lines.push('Company: ' + (fd.get('company') || '-'));
    lines.push('Email: ' + (fd.get('email') || ''));
    lines.push('Phone: ' + (fd.get('phone') || ''));
    lines.push('Service: ' + (fd.get('product') || fd.get('service') || ''));
    lines.push('Quantity: ' + (fd.get('quantity') || '-'));
    lines.push('Needed by: ' + (fd.get('needed_by') || '-'));
    lines.push('Details: ' + (fd.get('details') || fd.get('message') || ''));
    return lines.join('\n');
  }

  function openWhatsApp(text) {
    var num = (cfg.wa && cfg.wa.number) ? cfg.wa.number : '';
    if (!num) {
      alert('WhatsApp is not available right now. Please call or use the contact form.');
      return;
    }
    var url = 'https://wa.me/' + num + '?text=' + encodeURIComponent(text);
    window.open(url, '_blank', 'noopener');
  }

  function submitLeadThenWhatsApp(form) {
    var fd = new FormData(form);
    var source = form.getAttribute('data-lead-source') || 'website-quote';
    var btn = form.querySelector('[type="submit"]');
    var waText = buildWaMessage(form);

    function finishWa() {
      if (btn) {
        btn.disabled = false;
      }
      openWhatsApp(waText);
    }

    if (!cfg.ajaxUrl || !cfg.leadNonce) {
      finishWa();
      return;
    }

    if (btn) {
      btn.disabled = true;
    }

    var body = new FormData();
    body.append('action', 'amz_prints_submit_lead');
    body.append('nonce', cfg.leadNonce);
    body.append('source', source);
    body.append('name', fd.get('name') || '');
    body.append('company', fd.get('company') || '');
    body.append('email', fd.get('email') || '');
    body.append('phone', fd.get('phone') || '');
    body.append('product', fd.get('product') || fd.get('service') || '');
    body.append('quantity', fd.get('quantity') || '');
    body.append('needed_by', fd.get('needed_by') || '');
    body.append('details', fd.get('details') || fd.get('message') || '');
    body.append('message', fd.get('message') || fd.get('details') || '');

    // CRM first; WhatsApp always opens even if CRM fails.
    fetch(cfg.ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' })
      .catch(function () { /* ignore */ })
      .then(function () { finishWa(); });
  }

  document.querySelectorAll('[data-wa-form]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      submitLeadThenWhatsApp(form);
    });
  });

  document.querySelectorAll('[data-wa-service]').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      var service = btn.getAttribute('data-wa-service') || '';
      openWhatsApp('Hello, I would like to ask about: ' + service);
    });
  });

  /* WhatsApp float panel */
  var waToggle = document.getElementById('wa-flow-toggle');
  var waPanel = document.getElementById('wa-flow-panel');
  function setWaOpen(on) {
    if (!waPanel || !waToggle) return;
    waPanel.hidden = !on;
    waToggle.setAttribute('aria-expanded', on ? 'true' : 'false');
  }
  if (waToggle) {
    waToggle.addEventListener('click', function (e) {
      e.stopPropagation();
      setWaOpen(waPanel.hidden);
      setChatOpen(false);
    });
  }
  document.querySelectorAll('[data-open-wa]').forEach(function (el) {
    el.addEventListener('click', function (e) {
      e.preventDefault();
      if (cfg.wa && cfg.wa.href) window.open(cfg.wa.href, '_blank', 'noopener');
      else setWaOpen(true);
    });
  });

  /* AI Chat */
  var chatToggle = document.getElementById('ai-chat-toggle');
  var chatClose = document.getElementById('ai-chat-close');
  var chatPanel = document.getElementById('ai-chat-panel');
  var chatForm = document.getElementById('ai-chat-form');
  var chatInput = document.getElementById('ai-chat-input');
  var chatMessages = document.getElementById('ai-chat-messages');

  function setChatOpen(on) {
    if (!chatPanel || !chatToggle) return;
    chatPanel.hidden = !on;
    chatToggle.setAttribute('aria-expanded', on ? 'true' : 'false');
  }
  if (chatToggle) {
    chatToggle.addEventListener('click', function (e) {
      e.stopPropagation();
      setChatOpen(chatPanel.hidden);
      setWaOpen(false);
    });
  }
  if (chatClose) chatClose.addEventListener('click', function () { setChatOpen(false); });

  function addBubble(text, who) {
    if (!chatMessages) return;
    var div = document.createElement('div');
    div.className = 'ai-chat__bubble ai-chat__bubble--' + who;
    div.textContent = text;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }
  function addTyping() {
    var div = document.createElement('div');
    div.className = 'ai-chat__bubble ai-chat__bubble--bot ai-chat__typing';
    div.id = 'ai-typing';
    div.textContent = '...';
    chatMessages.appendChild(div);
  }
  function removeTyping() {
    var t = document.getElementById('ai-typing');
    if (t) t.remove();
  }
  function askAI(message) {
    addBubble(message, 'user');
    addTyping();
    var body = new FormData();
    body.append('action', 'amz_ai_chat');
    body.append('nonce', cfg.nonce || '');
    body.append('message', message);
    fetch(cfg.ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (json) {
        removeTyping();
        addBubble((json && json.data && json.data.reply) ? json.data.reply : 'Please try WhatsApp.', 'bot');
      })
      .catch(function () {
        removeTyping();
        addBubble('Connection error. Please use WhatsApp.', 'bot');
      });
  }
  if (chatForm && chatInput) {
    chatForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var msg = chatInput.value.trim();
      if (!msg) return;
      chatInput.value = '';
      askAI(msg);
    });
  }
  document.querySelectorAll('[data-ai-action]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var action = btn.getAttribute('data-ai-action');
      var chat = cfg.chat || {};
      if (action === 'quote' && chat.quote) { window.location.href = chat.quote; return; }
      if (action === 'track' && chat.track) { window.location.href = chat.track; return; }
      if (action === 'services' && chat.services) { window.location.href = chat.services; return; }
      if (action === 'whatsapp') {
        if (cfg.wa && cfg.wa.href) window.open(cfg.wa.href, '_blank', 'noopener');
        else setWaOpen(true);
      }
    });
  });

  /* ===== Press Atelier 3.0 motion ===== */
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var finePointer = window.matchMedia && window.matchMedia('(pointer: fine)').matches;

  /* Scroll progress */
  var progress = document.getElementById('amz-progress');
  function updateProgress() {
    if (!progress) return;
    var doc = document.documentElement;
    var max = doc.scrollHeight - window.innerHeight;
    var pct = max > 0 ? Math.min(100, Math.max(0, (window.scrollY / max) * 100)) : 0;
    progress.style.setProperty('--amz-progress', pct.toFixed(2) + '%');
  }
  window.addEventListener('scroll', updateProgress, { passive: true });
  updateProgress();

  /* Magnetic buttons */
  if (finePointer && !reduceMotion) {
    document.querySelectorAll('.btn--magnetic').forEach(function (btn) {
      btn.addEventListener('pointermove', function (e) {
        var r = btn.getBoundingClientRect();
        var x = e.clientX - r.left - r.width / 2;
        var y = e.clientY - r.top - r.height / 2;
        btn.style.transform = 'translate(' + (x * 0.18) + 'px,' + (y * 0.22) + 'px)';
      });
      btn.addEventListener('pointerleave', function () {
        btn.style.transform = '';
      });
    });
  }

  /* 3D tilt cards */
  if (finePointer && !reduceMotion) {
    document.querySelectorAll('.has-tilt').forEach(function (card) {
      card.addEventListener('pointermove', function (e) {
        var r = card.getBoundingClientRect();
        var px = (e.clientX - r.left) / r.width;
        var py = (e.clientY - r.top) / r.height;
        var rx = (0.5 - py) * 8;
        var ry = (px - 0.5) * 10;
        card.style.transform = 'perspective(900px) rotateX(' + rx + 'deg) rotateY(' + ry + 'deg) translateY(-2px)';
      });
      card.addEventListener('pointerleave', function () {
        card.style.transform = '';
      });
    });
  }

  /* Back to top */
  var backTop = document.getElementById('amz-back-top');
  if (backTop) {
    backTop.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' });
    });
  }

  /* Digital services stage slideshow */
  document.querySelectorAll('[data-ds-stage]').forEach(function (stage) {
    var imgs = Array.prototype.slice.call(stage.querySelectorAll('.ds-stage__img'));
    if (imgs.length < 2) return;
    var i = 0;
    if (reduceMotion) return;
    window.setInterval(function () {
      imgs[i].classList.remove('is-active');
      i = (i + 1) % imgs.length;
      imgs[i].classList.add('is-active');
    }, 4500);
  });
})();
